module.exports = {
   VERSION: "6",
   URL_MENU: "https://files.catbox.moe/i2q2u6.MP4",
   TOKEN: "8817261815:AAGRfO5Y8q9jLy3weJfu3pXNo7oVphQPAhU",
   OWNER: ["1164966985"],
   APIKEY: "ANGKASANYABOBO", // APIKEY AMBIL DI api.betabotz.eu.org
   NAMA_BOT: "ridocakepmd_bot",
   GROUP_ID: "-1004457556125", // ID GROUP SAMA DENGAN LINK INVITE
   CHANNEL_ID: "@panelrido", // USN CHANNEL
   LINK_INVITE: "https://t.me/+" // TAMBAHIN KAN LINK JIKA GROUP PRIVATE
};