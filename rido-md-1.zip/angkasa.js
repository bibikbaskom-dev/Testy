/*
  
  SC MD V5 BY ANGKASA
  
*/

const TelegramBot = require("node-telegram-bot-api");
const activeLinks = {};
const broadcastState = {};
const activeDiceGames = {};
const broadcastInProgress = {};
const fs = require("fs");
const os = require('os');
const path = require("path");
const chalk = require("chalk");
const axios = require("axios");
const archiver = require("archiver");
const pendingJoinMessages = {};
const pendingGta = new Map();
const pendingHitam = new Map();
const pendingAnime = new Map();
const pendingDisney = new Map();
const waitingForEmoji = new Map();
const pendingToFigure = new Map();
const animeResultCache = new Map();
const FormData = require("form-data");
const { Readable } = require("stream");
const moment = require('moment-timezone');
const filterFile = "./database/filters.json";
const JavaScriptObfuscator = require("javascript-obfuscator");
const groupsFile = "./database/groups.json";
const yts = require("yt-search");
const { exec } = require("child_process");
const { createCanvas, loadImage } = require('canvas');
const USERS_FILE = "./database/users.json"
const groupMessageFile = './database/group_message.json';
const DEFAULT_WELCOME_PIC = "./database/welcome.jpg";
const DEFAULT_LEFT_PIC = "./database/left.jpg";
const { VERSION, URL_MENU, TOKEN, OWNER, APIKEY, NAMA_BOT, CHANNEL_ID, GROUP_ID, LINK_INVITE, CHANNEL_INFO } = require("./config");

let maintenanceMode = false

const bot = new TelegramBot(TOKEN, { polling: true });
console.log("✅ Bot Jaga Group Active...");

//====================== LEWATI ERROR ===================

process.on("uncaughtException", (err) => {
  console.error("⚠️ Uncaught Exception:", err.message);
});

process.on("unhandledRejection", (reason, promise) => {
  console.error("⚠️ Unhandled Rejection:", reason);
});

//====================== ESCAPE CODE ===================

function escapeHtml(text) {
  if (typeof text !== "string") return text ?? "";
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function cleanAIResponse(text) {
  return text
    .replace(/\*\*/g, "")
    .replace(/\*/g, "")
    .replace(/__/g, "")
    .replace(/###/g, "")
    .replace(/---/g, "")
    .replace(/`/g, "")
    .replace(/>\s?/g, "")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]{2,}/g, " ")
    .replace(/\n +/g, "\n")
    .trim();
}

async function generateIdCard(user) {
    const width = 800;
    const height = 550; 
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, '#0f172a'); 
    gradient.addColorStop(1, '#020617');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.lineWidth = 2;
    roundRect(ctx, 40, 40, width - 80, height - 80, 25);
    ctx.stroke();

    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    roundRect(ctx, 40, 40, width - 80, height - 80, 25);
    ctx.fill();

    let photoUrl = null;
    try {
        const photos = await bot.getUserProfilePhotos(user.id, { limit: 1 });
        if (photos.total_count > 0) {
            const fileId = photos.photos[0][0].file_id;
            const fileLink = await bot.getFileLink(fileId);
            photoUrl = fileLink;
        }
    } catch (e) {
        console.log("Gagal ambil foto profil");
    }

    const imgX = 80;
    const imgY = 130;
    const imgSize = 200;

    if (photoUrl) {
        try {
            const image = await loadImage(photoUrl);
            ctx.save();
            ctx.beginPath();            ctx.arc(imgX + imgSize / 2, imgY + imgSize / 2, imgSize / 2, 0, Math.PI * 2, true);
            ctx.closePath();
            ctx.clip();
            ctx.drawImage(image, imgX, imgY, imgSize, imgSize);
            ctx.restore();
            
            ctx.beginPath();
            ctx.arc(imgX + imgSize / 2, imgY + imgSize / 2, imgSize / 2, 0, Math.PI * 2, true);
            ctx.lineWidth = 5;
            ctx.strokeStyle = '#ffffff';
            ctx.stroke();
        } catch (err) {
            drawPlaceholderAvatar(ctx, imgX, imgY, imgSize, user.first_name);
        }
    } else {
        drawPlaceholderAvatar(ctx, imgX, imgY, imgSize, user.first_name);
    }

    ctx.textAlign = 'left';
    
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'center';
    
    let cleanName = user.first_name.replace(/[^\w\s\-\u00C0-\u024F\u1E00-\u1EFF]/g, ''); 
    let displayName = cleanName.length > 25 ? cleanName.substring(0, 25) + '...' : cleanName;
    ctx.fillText(displayName, imgX + imgSize / 2, imgY - 20); 
    ctx.textAlign = 'left'; 

    ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
    roundRect(ctx, 80, 350, 200, 50, 10);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 18px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`ID: ${user.id}`, 180, 380);
    ctx.textAlign = 'left';

    const rightX = 320;
    
    ctx.fillStyle = '#94a3b8'; 
    ctx.font = 'bold 22px Arial';
    ctx.fillText('TELEGRAM', rightX, 110);

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 55px Arial';
    ctx.fillText('ID CARD', rightX, 160);

    ctx.fillStyle = '#38bdf8'; 
    ctx.font = '20px monospace';
    ctx.fillText(' rido - MD', rightX, 200);

    const startY = 260; 
    const gap = 70;

    const drawRow = (label, value, y) => {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
        roundRect(ctx, rightX, y - 30, 440, 50, 10);
        ctx.fill();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 22px Arial';
        ctx.fillText(`${label} :`, rightX + 25, y);

        ctx.fillStyle = '#94a3b8';
        ctx.font = '22px Arial';
        ctx.fillText(`${value}`, rightX + 160, y);
    };

    const dcId = Math.floor((user.id / Math.pow(2, 30)) % 5) + 1;
    const today = new Date().toISOString().split('T')[0];

    drawRow('User ID', user.id, startY);
    drawRow('Username', user.username ? `  @${user.username}` : 'Private', startY + gap);
    drawRow('Tanggal', today, startY + (gap * 2));
    drawRow('DC ID', dcId, startY + (gap * 3));

    ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.font = 'italic 16px Arial';
    ctx.textAlign = 'right';
    ctx.fillText('Generated by rido Md Bot • @ridororr', width - 60, height - 25);

    return canvas.toBuffer('image/png');
}
 
function roundRect(ctx, x, y, w, h, r) {
    if (w < 2 * r) r = w / 2;    if (h < 2 * r) r = h / 2;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
}

function drawPlaceholderAvatar(ctx, x, y, size, name) {
    ctx.fillStyle = '#334155';
    ctx.beginPath();
    ctx.arc(x + size/2, y + size/2, size/2, 0, Math.PI*2);
    ctx.fill();
    
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = 'bold 60px Arial';
    const initial = name ? name.charAt(0).toUpperCase() : '?';
    ctx.fillText(initial, x + size/2, y + size/2);
}

//====================== FUNCTION USER ===================

function loadUsers() {
  if (!fs.existsSync(USERS_FILE)) return {}
  return JSON.parse(fs.readFileSync(USERS_FILE))
}

function saveUsers(data) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 2))
}

function migrateUsersDatabase() {
  const users = loadUsers();
  let updated = false;

  for (const id in users) {
    if (users[id].wins === undefined) {
      users[id].wins = 0;
      updated = true;
    }

    if (users[id].losses === undefined) {
      users[id].losses = 0;
      updated = true;
    }

    if (users[id].draws === undefined) {
      users[id].draws = 0;
      updated = true;
    }
  }

  if (updated) {
    saveUsers(users);
    console.log("Users database migrated successfully.");
  }
}

function buildLink(id, invite) {
  if (invite) return invite; 
  if (!id) return null;
  if (id.startsWith("@")) return `https://t.me/${id.slice(1)}`;
  return null;
}

async function isJoinedFeature(userId) {
  const targets = [
    { id: CHANNEL_ID },
    { id: GROUP_ID, invite: LINK_INVITE }
  ];

  for (const t of targets) {
    try {
      if (t.id) {
        const member = await bot.getChatMember(t.id, userId);
        const validStatus = ["member", "administrator", "creator"];
        if (!validStatus.includes(member.status)) return false;
      }
    } catch (err) {
      return false;
    }
  }
  return true;
}

async function checkJoinFeature(msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (OWNER.includes(String(userId))) return true;

  const joined = await isJoinedFeature(userId);
  if (joined) return true;

  const groupUrl = buildLink(GROUP_ID, LINK_INVITE);
  const channelUrl = buildLink(CHANNEL_ID);

  const sentMsg = await bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Kamu harus join channel & group dulu!</blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          channelUrl ? [{ text: "Join Channel", url: channelUrl, style : "primary", icon_custom_emoji_id: "6098421155897545579" }] : [],
          groupUrl ? [{ text: "Join Group", url: groupUrl, style : "primary", icon_custom_emoji_id: "5258236805890710909" }] : [],
          [{ text: "Sudah Join", callback_data: `cekjoinfeature_${userId}`, style : "success", icon_custom_emoji_id: "5936067938955039275" }]
        ].filter(r => r.length > 0)
      }
    }
  );

  pendingJoinMessages[`${chatId}_${sentMsg.message_id}`] = userId;
  return false;
}

async function requireJoin(msg) {
  return await checkJoinFeature(msg);
}

//====================== FUNCTION GROUP ===================

async function isJoined(userId) {
  try {
    const ch = await bot.getChatMember(CHANNEL_ID, userId)
    const gp = await bot.getChatMember(GROUP_ID, userId)

    const validStatus = ["member", "administrator", "creator"]

    return validStatus.includes(ch.status) &&
           validStatus.includes(gp.status)
  } catch (err) {
    return false
  }
}

function loadGroups() {
  try {
    return JSON.parse(fs.readFileSync(groupsFile));
  } catch {
    return [];
  }
}

function saveGroups(data) {
  fs.writeFileSync(groupsFile, JSON.stringify(data, null, 2));
}

function initializeGroupsFromJson() {
  try {
    const groups = loadGroups();
    console.log(`✅ Grup berhasil dimuat dari file. Total: ${groups.length}`);
    return groups;
  } catch (err) {
    console.error("❌ Gagal memuat grup dari file:", err);
    return [];
  }
}

function getGroupMessages() {
    try {
    return JSON.parse(fs.readFileSync(groupMessageFile));
    } catch {
   return {};
  }
}

function saveGroupMessages(data) {
fs.writeFileSync(groupMessageFile, JSON.stringify(data, null, 2));
}

function loadFilters() {
  try {
    return JSON.parse(fs.readFileSync(filterFile));
  } catch {
    return {};
  }
}

function saveFilters(data) {
  fs.writeFileSync(filterFile, JSON.stringify(data, null, 2));
}

function getSettings() {
  try {
    return JSON.parse(fs.readFileSync(groupMessageFile));
  } catch {
    return {};
  }
}

function saveSettings(data) {
  fs.writeFileSync(groupMessageFile, JSON.stringify(data, null, 2));
}

function sendGroupList(chatId, page) {
  const groups = loadGroups();
  const perPage = 15;

  const totalPages = Math.ceil(groups.length / perPage);

  if (page < 1) page = 1;
  if (page > totalPages) page = totalPages;

  const start = (page - 1) * perPage;
  const end = start + perPage;

  const slice = groups.slice(start, end);

  let text = `<blockquote><tg-emoji emoji-id="5931718859366075705">📂</tg-emoji> Daftar Group</blockquote>\n`;
  text += `<blockquote><tg-emoji emoji-id="5033080906403808074">📝</tg-emoji> Page ${page}/${totalPages})</blockquote>\n\n`;
  if (slice.length === 0) {
    text += "_Tidak ada data group._";
  } else {
    slice.forEach(g => {
      text += `• ${g.title}\n⤷ ${g.id}\n`;
    });
  }

  text += `\n<blockquote><tg-emoji emoji-id="5319169695897632605">💃</tg-emoji> Total Group: ${groups.length}</blockquote>`;

  const keyboard = {
    inline_keyboard: []
  };

  let row = [];

  if (page > 1) {
    row.push({ text: "Back", callback_data: `listgb_${page - 1}`, style : "danger", icon_custom_emoji_id: "5258236805890710909" });
  }

  if (page < totalPages) {
    row.push({ text: "Next", callback_data: `listgb_${page + 1}`, style : "danger", icon_custom_emoji_id: "5260450573768990626" });
  }

  if (row.length > 0) keyboard.inline_keyboard.push(row);

  bot.sendMessage(chatId, text, {
    parse_mode: "HTML",
    reply_markup: keyboard
  });
}

function sendFilterPage(chatId, page) {
  const filters = loadFilters();
  if (!filters[chatId] || Object.keys(filters[chatId]).length === 0) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Tidak ada filter yang tersimpan.</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  const allFilters = Object.keys(filters[chatId]);
  const perPage = 5;
  const totalPage = Math.ceil(allFilters.length / perPage);

  if (page < 1) page = 1;
  if (page > totalPage) page = totalPage;

  const start = (page - 1) * perPage;
  const items = allFilters.slice(start, start + perPage);

  let text = `📜 *DAFTAR FILTER (Page ${page}/${totalPage})*\n\n`;

  items.forEach((keyword, index) => {
    const data = filters[chatId][keyword];
    text += `*${start + index + 1}. ${keyword}*\n`;
    text += `📝 Balasan: _${data.text || "-"}_\n`;
    text += `📎 Media: *${data.file ? data.file.type : "Tidak ada"}*\n`;
    text += `\n`;
  });

  const buttons = [];

  items.forEach((keyword) => {
    buttons.push([
      {
        text: `❌ Hapus "${keyword}"`,
        callback_data: `delfilter_${keyword}_${page}`
      }
    ]);
  });

  const navButtons = [];
  if (page > 1) navButtons.push({ text: "Prev", callback_data: `filterpage_${page - 1}`, style : "danger", icon_custom_emoji_id: "5258236805890710909" });
  if (page < totalPage) navButtons.push({ text: "Next", callback_data: `filterpage_${page + 1}`, style : "danger", icon_custom_emoji_id: "5260450573768990626" });

  if (navButtons.length > 0) buttons.push(navButtons);

  bot.sendMessage(chatId, text, {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: buttons }
  });
}

function isMaintenance(msg) {
  const userId = String(msg.from.id)

  if (maintenanceMode && !OWNER.includes(userId)) {
    bot.sendMessage(msg.chat.id,
      `<blockquote><tg-emoji emoji-id="5462921117423384478">🛠</tg-emoji> Bot maintenance.\nSedang Dalam Update/Perbaikan\nTunggu sampai selesai ya.</blockquote>`, {
        parse_mode: "HTML"
      }
    )
    return true
  }
  return false
}

function parseDuration(timeStr) {
  if (!timeStr) return 0;
  const match = timeStr.match(/^(\d+)(s|m|h|d)$/i);
  if (!match) return 0;
  
  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  
  switch (unit) {
    case 's': return value;
    case 'm': return value * 60;
    case 'h': return value * 3600;
    case 'd': return value * 86400;
    default: return 0;
  }
}

const getVps = () => {
  const uptimeSeconds = os.uptime();

  const days = Math.floor(uptimeSeconds / 86400);
  const hours = Math.floor((uptimeSeconds % 86400) / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = Math.floor(uptimeSeconds % 60);

  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
};

const getUptime = () => {
  const uptimeSeconds = Math.floor(process.uptime());

  const days = Math.floor(uptimeSeconds / 86400);
  const hours = Math.floor((uptimeSeconds % 86400) / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = uptimeSeconds % 60;

  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
};

//=================== FUNCTION FITUR ===================

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

const endpoints = [
  "cecan",
  "hijaber",
  "rikagusriani",
  "douyin",
  "ukhty",
  "bocil",
  "gheayubi",
  "anony",
  "euni",
  "natajadeh"
];

async function uploadToCatbox(buffer, filename) {
  const form = new FormData();

  const stream = Readable.from(buffer);

  form.append("reqtype", "fileupload");
  form.append("fileToUpload", stream, {
    filename: filename,
    contentType: "application/octet-stream"
  });

  const response = await axios.post(
    "https://catbox.moe/user/api.php",
    form,
    {
      headers: form.getHeaders(),
      maxContentLength: Infinity,
      maxBodyLength: Infinity
    }
  );

  return response.data;
}

async function processGta(msg, photoArray) {
  const chatId = msg.chat.id;

  const sent = await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Mengubah ke GTA style...</blockquote>`,
{ parse_mode: "HTML" });

  try {
    const photo = photoArray[photoArray.length - 1];
    const file = await bot.getFile(photo.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;

    const imageRes = await axios.get(fileUrl, {
      responseType: "arraybuffer"
    });

    const publicUrl = await uploadToTmpfiles(Buffer.from(imageRes.data));

    const apiUrl = `https://api.betabotz.eu.org/api/maker/jadigta?url=${encodeURIComponent(publicUrl)}&apikey=${APIKEY}`;

    const response = await axios.get(apiUrl);

    if (!response.data.status) {
      return bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API gagal memproses gambar</blockquote>`,
        {
          chat_id: chatId,
          message_id: sent.message_id,
          parse_mode: "HTML"
        }
      );
    }

    const resultUrl = response.data.result;

    await bot.sendPhoto(chatId, resultUrl, {
      caption: `<blockquote><tg-emoji emoji-id="6046412971708518490">🎮</tg-emoji> Efek: GTA Style
<tg-emoji emoji-id="6298630163047387557">🔥</tg-emoji> Hasil: Grand Theft Auto Mode
<tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> By Angkasa Stecu</blockquote>`,
      parse_mode: "HTML"
    });

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("GTA ERROR FULL:", err.response?.data || err.message);

    await bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat GTA style
${err.message}
</blockquote>`,
      {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      }
    );
  }
}

async function uploadToTmpfiles(buffer) {
  const form = new FormData();
  form.append("file", buffer, "image.jpg");

  const res = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
    headers: form.getHeaders()
  });

  const rawUrl = res.data.data.url;
  return rawUrl.replace("tmpfiles.org/", "tmpfiles.org/dl/");
}

async function processToFigure(msg, photoArray) {
  const chatId = msg.chat.id;

  const sent = await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Mengubah ke Figure...</blockquote>`,
{ parse_mode: "HTML" });

  try {
    const photo = photoArray[photoArray.length - 1];
    const file = await bot.getFile(photo.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;

    const imageRes = await axios.get(fileUrl, {
      responseType: "arraybuffer"
    });

    const publicUrl = await uploadToTmpfiles(Buffer.from(imageRes.data));

    const apiUrl = `https://api.betabotz.eu.org/api/maker/tofigurev2?url=${encodeURIComponent(publicUrl)}&apikey=${APIKEY}`;

    const response = await axios.get(apiUrl, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const contentType = response.headers["content-type"] || "";

    if (!contentType.includes("image")) {
      console.log("TOFIGURE API ERROR:", response.data.toString());

      return bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API tidak mengirim gambar</blockquote>`,
        {
          chat_id: chatId,
          message_id: sent.message_id,
          parse_mode: "HTML"
        }
      );
    }

    await bot.sendPhoto(chatId, Buffer.from(response.data), {
      caption: `<blockquote><tg-emoji emoji-id="5033108527338488459">🖼</tg-emoji> Efek: Figure Style
<tg-emoji emoji-id="6298630163047387557">🔥</tg-emoji> Hasil: Figure + Box + Komputer
<tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> By Angkasa Stecu
</blockquote>`,
      parse_mode: "HTML"
    });

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {
    console.log("TOFIGURE ERROR FULL:", err.response?.data || err.message);

    await bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat Figure
${err.message}
</blockquote>`,
      {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      }
    );
  }
}

async function processHitam(msg, photoArray) {
  const chatId = msg.chat.id;

  const sent = await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Menghitamkan gambar...</blockquote>`,
{ parse_mode: "HTML" });

  try {
    const photo = photoArray[photoArray.length - 1];
    const file = await bot.getFile(photo.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;

    const imageRes = await axios.get(fileUrl, {
      responseType: "arraybuffer"
    });

    const publicUrl = await uploadToTmpfiles(Buffer.from(imageRes.data));

    const apiUrl = `https://api.betabotz.eu.org/api/maker/jadihitam?url=${encodeURIComponent(publicUrl)}&apikey=${APIKEY}`;

    const response = await axios.get(apiUrl, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const contentType = response.headers["content-type"] || "";

    if (!contentType.includes("image")) {
      console.log("HITAM API ERROR:", response.data.toString());

      return bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API tidak mengirim gambar</blockquote>`,
        {
          chat_id: chatId,
          message_id: sent.message_id,
          parse_mode: "HTML"
        }
      );
    }

    await bot.sendPhoto(chatId, Buffer.from(response.data), {
      caption: `<blockquote><tg-emoji emoji-id="5363838691510873846">🖤</tg-emoji> Efek: Hitam Style
<tg-emoji emoji-id="6298630163047387557">🔥</tg-emoji> Hasil: Ubah Kulit Menjadi Hitam
<tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> By Angkasa Stecu</blockquote>`,
      parse_mode: "HTML"
    });

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("HITAM ERROR FULL:", err.response?.data || err.message);

    await bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal memproses gambar
${err.message}
</blockquote>`,
      {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      }
    );
  }
}

async function processDisney(msg, photoArray) {
  const chatId = msg.chat.id;

  const sent = await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Mengubah ke Disney style...</blockquote>`,
{ parse_mode: "HTML" });

  try {
    const photo = photoArray[photoArray.length - 1];
    const file = await bot.getFile(photo.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;

    const imageRes = await axios.get(fileUrl, {
      responseType: "arraybuffer"
    });

    const publicUrl = await uploadToTmpfiles(Buffer.from(imageRes.data));

    const apiUrl = `https://api.betabotz.eu.org/api/maker/jadidisney?url=${encodeURIComponent(publicUrl)}&apikey=${APIKEY}`;

    const response = await axios.get(apiUrl, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const contentType = response.headers["content-type"] || "";

    if (!contentType.includes("image")) {
      console.log("DISNEY API ERROR:", response.data.toString());

      return bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API tidak mengirim gambar</blockquote>`,
        {
          chat_id: chatId,
          message_id: sent.message_id,
          parse_mode: "HTML"
        }
      );
    }

    await bot.sendPhoto(chatId, Buffer.from(response.data), {
      caption: `<blockquote><tg-emoji emoji-id="5323276453431775004">🏰</tg-emoji> Efek: Disney Style
<tg-emoji emoji-id="6298630163047387557">🔥</tg-emoji> Hasil: Mengubah Foto Menjadi Cartoon
<tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> By Angkasa Stecu
</blockquote>`,
      parse_mode: "HTML"
    });

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("DISNEY ERROR FULL:", err.response?.data || err.message);

    await bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat Disney style
${err.message}
</blockquote>`,
      {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      }
    );
  }
}

async function processAnime(msg, photoArray) {
  const chatId = msg.chat.id;

  const sent = await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Mengubah ke Anime style...</blockquote>`,
{ parse_mode: "HTML" });

  try {
    const photo = photoArray[photoArray.length - 1];
    const file = await bot.getFile(photo.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;

    const imageRes = await axios.get(fileUrl, {
      responseType: "arraybuffer"
    });

    const publicUrl = await uploadToTmpfiles(Buffer.from(imageRes.data));

    const apiUrl = `https://api.betabotz.eu.org/api/maker/jadianime?url=${encodeURIComponent(publicUrl)}&apikey=${APIKEY}`;

    const response = await axios.get(apiUrl);

    if (!response.data.status) {
      return bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API gagal memproses gambar</blockquote>`,
        {
          chat_id: chatId,
          message_id: sent.message_id,
          parse_mode: "HTML"
        }
      );
    }

    const result = response.data.result;

    animeResultCache.set(chatId, {
      img1: result.img_1,
      img2: result.img_2
    });

    await bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5431538972507522948">🎌</tg-emoji> Anime Style Siap!
Silakan pilih versi:
</blockquote>`,
      {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "Versi 2D", callback_data: "anime_2d", style : "primary", icon_custom_emoji_id: "5400011223905345095" },
              { text: "Versi 3D", callback_data: "anime_3d", style : "primary", icon_custom_emoji_id: "5206502842478638898" }
            ]
          ]
        }
      }
    );

  } catch (err) {
    console.log("ANIME ERROR FULL:", err.response?.data || err.message);

    await bot.editMessageText(
`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat Anime style
${err.message}
</blockquote>`,
      {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      }
    );
  }
}

//====================== START MENU ===================

bot.onText(/^\/start(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const username = escapeHtml(msg.from.first_name || "User");
  const userId = msg.from.id;
  const chatType = msg.chat.type;
  const RUNTIME = getUptime();
  const VPSTIME = getVps()
  
  if (isMaintenance(msg)) return;

  const users = loadUsers();

  if (chatType === "private") {

    if (!users[userId]) {
    users[userId] = {
      id: userId,
      username: msg.from.username || null,
      first_name: msg.from.first_name,
      joinedAt: Date.now(),
      wins: 0,
      losses: 0,
      draws: 0
    };

    saveUsers(users);

    const totalUsers = Object.keys(users).length;

    const mention = msg.from.username
      ? `@${msg.from.username}`
      : `<a href="tg://user?id=${userId}">${escapeHtml(msg.from.first_name)}</a>`;
    const waktuStr = moment().tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss") + " WIB";
    
    const textNotif = `<blockquote><b><tg-emoji emoji-id="5443038326535759644">💬</tg-emoji> User Baru Terdeteksi!</b></blockquote>
<blockquote><tg-emoji emoji-id="4967667085606912536">👤</tg-emoji> Nama: ${escapeHtml(msg.from.first_name)}
<tg-emoji emoji-id="5334890573281114250">🆔</tg-emoji> ID: <code>${userId}</code>
<tg-emoji emoji-id="5990023031819341856">🔗</tg-emoji> Username: ${msg.from.username ? '@' + msg.from.username : 'Tidak ada'}

<tg-emoji emoji-id="5364265190353286344">📊</tg-emoji> User ke: <b>${totalUsers}</b>
<tg-emoji emoji-id="5453957997418004470">👥</tg-emoji> Total Users: <b>${totalUsers}</b>

<tg-emoji emoji-id="5969545478155539601">⏰</tg-emoji> Waktu: ${waktuStr}
</blockquote>
`;

    if (CHANNEL_INFO) {
      bot.sendMessage(CHANNEL_INFO, textNotif, {
        parse_mode: "HTML"
      }).catch(() => {});
    }
 
      if (Array.isArray(OWNER)) {
        OWNER.forEach(ownerId => {
          bot.sendMessage(ownerId, textNotif, {
            parse_mode: "HTML"
          }).catch(() => {});
        });
      }
    }
  }

  if (chatType !== "private") {
    if (!users[userId] && !OWNER.includes(String(userId))) {
      return bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Kamu belum terdaftar.\nSilakan start bot di private dulu.</blockquote>`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                {
                  text: "Start Private",
                  url: `https://t.me/${NAMA_BOT}`,
                  style : "success", 
                  icon_custom_emoji_id: "5990023031819341856"
                }
              ]
            ]
          }
        }
      );
    }
  }

  if (!OWNER.includes(String(userId))) {

    const joined = await isJoined(userId);

    if (!joined) {

      const groupUrl = buildLink(GROUP_ID, LINK_INVITE);
      const channelUrl = buildLink(CHANNEL_ID);

      const sentMsg = await bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Kamu harus join channel & group dulu!</blockquote>`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              channelUrl ? [{ text: "Join Channel", url: channelUrl, style : "primary", icon_custom_emoji_id: "6098421155897545579" }] : [],
              groupUrl ? [{ text: "Join Group", url: groupUrl, style : "primary", icon_custom_emoji_id: "5258236805890710909" }] : [],
              [{ text: "Sudah Join", callback_data: `cekjoin_${userId}`, style : "success", icon_custom_emoji_id: "5936067938955039275" }]
            ].filter(row => row.length > 0)
          }
        }
      );
      
      pendingJoinMessages[`${chatId}_${sentMsg.message_id}`] = userId;

      return;
    }
  }

  const menuPhoto = `${URL_MENU}`;
  const totalGroups = loadGroups().length;
  const totalUsers = Object.keys(users).length;

  const caption = `<blockquote><tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>°𝙰𝙽𝙶𝙺𝙰𝚂𝙰𝙼𝙳</blockquote>
<blockquote>𝚆𝙴𝙻𝙲𝙾𝙼𝙴 ${username} 𝚃𝙾 𝙰𝙽𝙶𝙺𝙰𝚂𝙰 𝙼𝚄𝙻𝚃𝙸 𝙳𝙴𝚅𝙸𝚅𝙴
<tg-emoji emoji-id="5841403144604487992">🔔</tg-emoji> 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : ${VERSION}
<tg-emoji emoji-id="5402355073458123173">⌛️</tg-emoji> 𝙱𝙾𝚃 𝚃𝙸𝙼𝙴 : ${RUNTIME}
<tg-emoji emoji-id="5992087137267225105">💻</tg-emoji> 𝚅𝙿𝚂 𝚃𝙸𝙼𝙴 : ${VPSTIME}
<tg-emoji emoji-id="5879770735999717115">👤</tg-emoji> 𝚃𝙾𝚃𝙰𝙻 𝚄𝚂𝙴𝚁 : ${totalUsers}
<tg-emoji emoji-id="5931472654660800739">📊</tg-emoji> 𝙹𝚄𝙼𝙻𝙰𝙷 𝙶𝚁𝙾𝚄𝙿 : ${totalGroups}</blockquote>
<blockquote><tg-emoji emoji-id="6165775219580472827">☠</tg-emoji> Silakan pilih menu di bawah ini untuk mulai.</blockquote>`;

  const options = {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "𝙼𝚎𝚗𝚞 𝙾𝚠𝚗𝚎𝚛", callback_data: "menuowner", style: "danger", icon_custom_emoji_id: "5411430859045626151" }
        ],
        [
          { text: "𝙼𝚎𝚗𝚞 𝙰𝚍𝚖𝚒𝚗", callback_data: "menuadmin", style: "primary", icon_custom_emoji_id: "5411419730785369685" },
          { text: "𝙼𝚎𝚗𝚞 𝙹𝚊𝚐𝚊 𝙶𝚋", callback_data: "menujagagroup", style: "primary", icon_custom_emoji_id: "5411329291659013967" }
        ],
        [
          { text: "𝙼𝚎𝚗𝚞 𝙶𝚊𝚖𝚎𝚜", callback_data: "menugames", style: "success", icon_custom_emoji_id: "5368499186293564526" }
        ],
        [
          { text: "𝙼𝚎𝚗𝚞 𝙼𝚘𝚛𝚎", callback_data: "menumore", style: "primary", icon_custom_emoji_id: "5463343407197878047" },
          { text: "𝚃𝚚𝚝𝚘", callback_data: "tqto", style: "primary", icon_custom_emoji_id: "5408997339165653167" }
        ],
        [
          { text: "𝙲𝚑𝚊𝚗𝚗𝚎𝚕", url: "https://t.me/angkasanyabadmood", style: "danger", icon_custom_emoji_id: "5409087245716056598" }
        ],
        [
          { text: "𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛", url: "https://t.me/angkasanyabobo", style: "primary", icon_custom_emoji_id: "5463039890449003865" },
          { text: "𝙲𝚞𝚕𝚒𝚔 𝙱𝚘𝚝", url: `https://t.me/${NAMA_BOT}?startgroup=true`, style: "primary", icon_custom_emoji_id: "5463257460607315631" }
        ]
      ],
    },
  };

  try {
    await bot.sendPhoto(chatId, menuPhoto, {
      caption,
      ...options,
    });
  } catch (err) {
    console.error("❌ Gagal kirim menu start:", err);
  }
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const username = escapeHtml(query.from.first_name || "User");
  const data = query.data;
  const users = loadUsers();
  const totalGroups = loadGroups().length;
  const totalUsers = Object.keys(users).length;
  const userId = query.from.id;
  const RUNTIME = getUptime();
  const VPSTIME = getVps();
  
  if (isMaintenance(query)) return
  
  if (data.startsWith("cekjoin_")) {

  const targetUserId = parseInt(data.split("_")[1]);

  if (userId !== targetUserId) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Tombol ini bukan untuk kamu!",
      show_alert: true
    });
  }

  const joined = await isJoined(userId);

    if (!joined) {
      return bot.answerCallbackQuery(query.id, {
        text: "❌ Kamu belum join semua!",
        show_alert: true
      });
    }

    await bot.answerCallbackQuery(query.id, {
      text: "✅ Verifikasi berhasil!"
    });

    await bot.deleteMessage(chatId, messageId).catch(() => {});

    delete pendingJoinMessages[`${chatId}_${messageId}`];

    bot.emit("text", {
      ...query.message,
      text: "/start",
      from: query.from
    });

    return; // WAJIB supaya tidak lanjut
  }
  
  if (data.startsWith("cekjoinfeature_")) {
    const targetUserId = parseInt(data.split("_")[1]);
      if (userId !== targetUserId) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Ini bukan untukmu!", show_alert: true });
      }

    const joined = await isJoinedFeature(userId);

    if (joined) {
      await bot.answerCallbackQuery(query.id, { text: "✅ Berhasil! Kamu sudah join semua channel & group.", show_alert: true });

      setTimeout(async () => {
        try { await bot.deleteMessage(chatId, messageId); } catch {}
        delete pendingJoinMessages[`${chatId}_${messageId}`];
      }, 2000);

      return;
    } else {
      return bot.answerCallbackQuery(query.id, { text: "❌ Masih ada channel/group yang belum kamu join!", show_alert: true });
    }
  }
  
  if (data.startsWith("chooseRole_") || data.startsWith("role_")) return;

  if (data.startsWith("listuser_")) {

  const parts = data.split("_");
  const page = parseInt(parts[1]);
  const perPage = 20;

  if (!OWNER.includes(String(userId))) {
    return bot.answerCallbackQuery(query.id, {
      text: "🚫 Fitur ini khusus owner!",
      show_alert: true
    });
  }

  const users = loadUsers();
  const userList = Object.values(users);

  if (userList.length === 0) {
    return bot.answerCallbackQuery(query.id, {
      text: "Tidak ada user.",
      show_alert: true
    });
  }

  const totalPages = Math.ceil(userList.length / perPage);

  if (page < 1 || page > totalPages) {
    return bot.answerCallbackQuery(query.id);
  }

  const start = (page - 1) * perPage;
  const end = start + perPage;
  const pageData = userList.slice(start, end);

  let text = `<blockquote><b><tg-emoji emoji-id="4958506272551863292">📊</tg-emoji> TOTAL USER:</b> ${userList.length}\n`;
  text += `<b><tg-emoji emoji-id="5256113064821926998">📄</tg-emoji> Page:</b> ${page}/${totalPages}</blockquote>\n`;

  pageData.forEach((u, i) => {
    text += `<b>${start + i + 1}.</b> ${u.first_name || "-"} `;
    if (u.username) text += `(@${u.username}) <tg-emoji emoji-id="5208748315805499400">✅</tg-emoji>`;
    text += `\n<code>ID:</code> ${u.id}\n\n`;
  });

  const buttons = [];

  if (page > 1) {
    buttons.push({
      text: "Back",
      callback_data: `listuser_${page - 1}`,
      style : "danger",
      icon_custom_emoji_id: "5258236805890710909"
    });
  }

  if (page < totalPages) {
    buttons.push({
      text: "Next",
      callback_data: `listuser_${page + 1}`,
      style : "danger",
      icon_custom_emoji_id: "5260450573768990626"
    });
  }

  await bot.editMessageText(text, {
    chat_id: chatId,
    message_id: messageId,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [buttons]
    }
  });

    return;
  }

  try {
    if (data === "menuowner") {
      await bot.editMessageMedia(
        {
          type: "photo",
          media: `${URL_MENU}`,
          caption: `<blockquote><tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>°𝙰𝙽𝙶𝙺𝙰𝚂𝙰𝙼𝙳</blockquote>
<blockquote>╔─═⊱ 𝐌𝐄𝐍𝐔 𝐎𝐖𝐍𝐄𝐑 <tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> ─═⪼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /maintenance
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝚈𝚂𝚃𝙴𝙼 𝙿𝙴𝚁𝙱𝙰𝙸𝙺𝙰𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /listuser
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙻𝙸𝚂𝚃 𝙳𝙰𝙵𝚃𝙰𝚁 𝚄𝚂𝙴𝚁
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /listgb
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙻𝙸𝚂𝚃 𝙶𝚁𝙾𝚄𝙿 𝚃𝙴𝚁𝙳𝙰𝙵𝚃𝙰𝚁
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /backup
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙱𝙰𝙲𝙺𝚄𝙿 𝚂𝙴𝙼𝚄𝙰 𝙵𝙸𝙻𝙴
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /bc
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙱𝚁𝙾𝙰𝙳𝙲𝙰𝚂𝚃 𝚄𝚂𝙴𝚁/𝙶𝚁𝙾𝚄𝙿
╚━═━═━═━═━═━═━═━═━═━═⪼</blockquote>`,
          parse_mode: "HTML",
        },
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: {
            inline_keyboard: [
              [{ text: "𝙱𝚊𝚌𝚔", callback_data: "back_home", style : "danger", icon_custom_emoji_id: "5258236805890710909" }],
            ],
          },
        }
      );
    }
    
    if (data === "menuadmin") {
      await bot.editMessageMedia(
        {
          type: "photo",
          media: `${URL_MENU}`,
          caption: `<blockquote><tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>°𝙰𝙽𝙶𝙺𝙰𝚂𝙰𝙼𝙳</blockquote>
<blockquote>╔─═⊱ 𝐌𝐄𝐍𝐔 𝐀𝐃𝐌𝐈𝐍 <tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> ─═⪼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /link
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙿𝚁𝙸𝚅𝙰𝚃𝙴 𝙻𝙸𝙽𝙺
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /pin
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝙴𝙼𝙰𝚃𝙺𝙰𝙽 𝙿𝙴𝚂𝙰𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /unpin
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝚂𝙴𝙼𝙰𝚃 𝙿𝙴𝚂𝙰𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /mute
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙲𝙷𝙰𝚃 𝙾𝙵𝙵
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /unmute
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙲𝙷𝙰𝚃 𝙾𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /promote
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙹𝙰𝙳𝙸𝙺𝙰𝙽 𝙰𝙳𝙼𝙸𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /demote
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙹𝙰𝙳𝙸𝙺𝙰𝙽 𝙼𝙴𝙼𝙱𝙴𝚁
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /setwelcome
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚃𝙴𝚇𝚃 𝙽𝙴𝚆 𝙼𝙴𝙼𝙱𝙴𝚁
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /setleft
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚃𝙴𝚇𝚃 𝙻𝙴𝙵𝚃 𝙶𝚁𝙾𝚄𝙿
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /setpic
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝙴𝚃 𝙿𝙸𝙲 𝚆𝙴𝙻𝙲𝙾𝙼𝙴/𝙻𝙴𝙵𝚃
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /setcontact
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝙴𝚃 𝙱𝚄𝚃𝚃𝙾𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /setcn
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙱𝚄𝙰𝚃 𝙱𝚄𝚃𝚃𝙾𝙽 𝙲𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /settime
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙳𝚄𝚁𝙰𝚂𝙸 𝙲𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /filter
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙱𝚄𝙰𝚃 𝚁𝙴𝚂𝙿𝙾𝙽 𝚃𝙴𝚇𝚃
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /listfilter
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙻𝙸𝚂𝚃 𝚃𝙴𝚇𝚃 𝙵𝙸𝙻𝚃𝙴𝚁
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /open
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙱𝚄𝙺𝙰 𝙶𝚁𝙾𝚄𝙿
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /close
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚃𝚄𝚃𝚄𝙿 𝙶𝚁𝙾𝚄𝙿
╚━═━═━═━═━═━═━═━═━═━═⪼</blockquote>`,
          parse_mode: "HTML",
        },
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: {
            inline_keyboard: [
              [{ text: "𝙱𝚊𝚌𝚔", callback_data: "back_home", style : "danger", icon_custom_emoji_id: "5258236805890710909" }],
            ],
          },
        }
      );
    }
    
    if (data === "menujagagroup") {
      await bot.editMessageMedia(
        {
          type: "photo",
          media: `${URL_MENU}`,
          caption: `<blockquote><tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>°𝙰𝙽𝙶𝙺𝙰𝚂𝙰𝙼𝙳</blockquote>
<blockquote>╔─═⊱ 𝐌𝐄𝐍𝐔 𝐉𝐀𝐆𝐀 𝐆𝐑𝐎𝐔𝐏 <tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> ─═⪼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antilink
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝙻𝙸𝙽𝙺
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antiforward
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝙿𝙴𝚂𝙰𝙽 𝚃𝙴𝚁𝚄𝚂𝙰𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /antifoto
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙷𝙰𝙿𝚄𝚂 𝙵𝙾𝚃𝙾
╚━═━═━═━═━═━═━═━═━═━═⪼</blockquote>`,
          parse_mode: "HTML",
        },
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: {
            inline_keyboard: [
              [{ text: "𝙱𝚊𝚌𝚔", callback_data: "back_home", style : "danger", icon_custom_emoji_id: "5258236805890710909" }],
            ],
          },
        }
      );
    }
    
    if (data === "menugames") {
      await bot.editMessageMedia(
        {
          type: "photo",
          media: `${URL_MENU}`,
          caption: `<blockquote><tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>°𝙰𝙽𝙶𝙺𝙰𝚂𝙰𝙼𝙳</blockquote>
<blockquote>╔─═⊱ 𝐌𝐄𝐍𝐔 𝐆𝐀𝐌𝐄𝐒 <tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> ─═⪼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /top
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙿𝙴𝚁𝙸𝙽𝙶𝙺𝙰𝚃 𝚃𝙾𝙿 𝙳𝙰𝙳𝚄
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /dadu
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙳𝙰𝙳𝚄 𝙿𝚅𝙿
╚━═━═━═━═━═━═━═━═━═━═⪼</blockquote>`,
          parse_mode: "HTML",
        },
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: {
            inline_keyboard: [
              [{ text: "𝙱𝚊𝚌𝚔", callback_data: "back_home", style : "danger", icon_custom_emoji_id: "5258236805890710909" }],
            ],
          },
        }
      );
    }

    if (data === "menumore") {
      await bot.editMessageMedia(
        {
          type: "photo",
          media: `${URL_MENU}`,
          caption: `<blockquote><tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>°𝙰𝙽𝙶𝙺𝙰𝚂𝙰𝙼𝙳</blockquote>
<blockquote>╔─═⊱ 𝐌𝐄𝐍𝐔 𝐌𝐎𝐑𝐄 <tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> ─═⪼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /ping
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚃𝙴𝚂𝚃 𝙺𝙴𝙲𝙴𝙿𝙰𝚃𝙰𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /ai
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝙴𝙰𝚁𝙲𝙷
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /enchard
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝙴𝙽𝙶𝙴𝙽𝙺𝚁𝙸𝙿𝚂𝙸
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /tourl
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙼𝙴𝙳𝙸𝙰 𝙺𝙴 𝚄𝚁𝙻
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /tiktok
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙳𝙾𝚆𝙽𝙻𝙾𝙰𝙳 𝚅𝙸𝙳 𝚃𝙸𝙺𝚃𝙾𝙺
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /play
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝙴𝙰𝚁𝙲𝙷 𝙼𝚄𝚂𝙸𝙲
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /iqc
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙸𝙿𝙷𝙾𝙽𝙴 𝚀𝚄𝙾𝚃𝙴
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /brat
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝚃𝙸𝙲𝙺𝙴𝚁 𝚃𝙴𝚇𝚃
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /bratvid
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝚃𝙸𝙲𝙺𝙴𝚁 𝙰𝙽𝙸𝙼𝙰𝚂𝙸
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /stalktt
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙺𝙴𝙿𝙾𝙸𝙽 𝚃𝙸𝙺𝚃𝙾𝙺
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /stalkig
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙺𝙴𝙿𝙾𝙸𝙽 𝙸𝙽𝚂𝚃𝙰𝙶𝚁𝙰𝙼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /asupan
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚁𝙰𝙽𝙳𝙾𝙼 𝙰𝚂𝚄𝙿𝙰𝙽
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /cekid
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙲𝙴𝙺 𝙸𝙳 𝚄𝚂𝙴𝚁
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /gta
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙵𝙾𝚃𝙾 𝚂𝚃𝚈𝙻𝙴 𝙶𝚃𝙰
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /tofigure
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙵𝙾𝚃𝙾 𝚂𝚃𝚈𝙻𝙴 𝙵𝙸𝙶𝚄𝚁𝙴
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /hytamkan
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙵𝙾𝚃𝙾 𝚂𝚃𝚈𝙻𝙴 𝙷𝙸𝚃𝙰𝙼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /disney
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙵𝙾𝚃𝙾 𝚂𝚃𝚈𝙻𝙴 𝙳𝙸𝚂𝙽𝙴𝚈
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /anime
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚄𝙱𝙰𝙷 𝙵𝙾𝚃𝙾 𝚂𝚃𝚈𝙻𝙴 𝙰𝙽𝙸𝙼𝙴
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> /cekemoji
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙲𝙴𝙺 𝙸𝙳 𝙴𝙼𝙾𝙹𝙸 𝙿𝚁𝙴𝙼
╚━═━═━═━═━═━═━═━═━═━═⪼</blockquote>`,
          parse_mode: "HTML",
        },
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: {
            inline_keyboard: [
              [{ text: "𝙱𝚊𝚌𝚔", callback_data: "back_home", style : "danger", icon_custom_emoji_id: "5258236805890710909" }],
            ],
          },
        }
      );
    }
    
    if (data === "tqto") {
      await bot.editMessageMedia(
        {
          type: "photo",
          media: `${URL_MENU}`,
          caption: `<blockquote><tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>°𝙰𝙽𝙶𝙺𝙰𝚂𝙰𝙼𝙳</blockquote>
<blockquote>╔─═⊱ 𝐌𝐘 𝐒𝐔𝐏𝐏𝐎𝐑𝐓 <tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> ─═⪼
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝙰𝙻𝙻𝙰𝙷 𝚂𝚆𝚃
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙶𝙾𝙳
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> ࿈𝙰𝙽𝙶𝙺𝙰𝚂𝙰𝙽𝚈𝙰𝙱𝙾𝙱𝙾࿈
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙳𝙴𝚅𝙴𝙻𝙾𝙿𝙴𝚁 𓆩♕𓆪
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝚃𝙷𝙴𝙺𝚈𝚁𝙾
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙰𝙳𝙴𝙺
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝙾𝙻𝚈𝙽𝙴𝙴𝙴
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙰𝙳𝙴𝙺
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝙶𝙰𝙱𝚁𝙸𝙴𝙻𝚃𝚉𝚈𝙿𝚁𝙾𝙾𝙾𝙾𝙾𝙻
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙵𝚁𝙸𝙴𝙽𝙳
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝚃𝙰𝙺𝙰
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙵𝚁𝙸𝙴𝙽𝙳
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝚇𝚈𝚁𝙰𝙰 - 𝙼𝙳
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙵𝚁𝙸𝙴𝙽𝙳
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝙺𝙴𝙻𝚁𝙰
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙵𝚁𝙸𝙴𝙽𝙳
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝚂𝙰𝙻 𝙻𝚄𝚅2𝙷𝙰𝚃𝙴
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙵𝚁𝙸𝙴𝙽𝙳
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝚇𝙴𝙽𝙾𝙽
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙵𝚁𝙸𝙴𝙽𝙳
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝙵𝚃𝙼𝙽𝙲𝙻𝙾𝚄𝙳
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙵𝚁𝙸𝙴𝙽𝙳
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝙶𝙰𝙱𝚁𝙸𝙴𝙻𝙽𝚈𝙰𝙱𝙾𝙱𝙾
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝙼𝚈 𝙵𝚁𝙸𝙴𝙽𝙳
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝙰𝙻𝙻 𝙿𝙰𝚁𝚃𝙽𝙴𝚁
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝚄𝙿𝙿𝙾𝚁𝚃
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝙰𝙻𝙻 𝚂𝙴𝙻𝙻𝙴𝚁
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝚄𝙿𝙿𝙾𝚁𝚃
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝙰𝙻𝙻 𝙱𝚄𝚈𝙴𝚁
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝚄𝙿𝙿𝙾𝚁𝚃
║
║<tg-emoji emoji-id="5260450573768990626">➡️</tg-emoji> 𝙷𝙴𝚃𝚃𝙴𝚁𝚂
║<tg-emoji emoji-id="6046530293035176435">🔥</tg-emoji> 𝚂𝚄𝙿𝙿𝙾𝚁𝚃 𝚂𝚈𝚂𝚃𝙴𝙼
╚━═━═━═━═━═━═━═━═━═━═⪼</blockquote>`,
          parse_mode: "HTML",
        },
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: {
            inline_keyboard: [
              [{ text: "𝙱𝚊𝚌𝚔", callback_data: "back_home", style : "danger", icon_custom_emoji_id: "5258236805890710909" }],
            ],
          },
        }
      );
    }

    if (data === "back_home") {
      await bot.editMessageMedia(
        {
          type: "photo",
          media: `${URL_MENU}`,
          caption: `<blockquote><tg-emoji emoji-id="5411301743738777449">🎩</tg-emoji>°𝙰𝙽𝙶𝙺𝙰𝚂𝙰𝙼𝙳</blockquote>
<blockquote>𝚆𝙴𝙻𝙲𝙾𝙼𝙴 ${username} 𝚃𝙾 𝙰𝙽𝙶𝙺𝙰𝚂𝙰 𝙼𝚄𝙻𝚃𝙸 𝙳𝙴𝚅𝙸𝙲𝙴
<tg-emoji emoji-id="5841403144604487992">🔔</tg-emoji> 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : ${VERSION}
<tg-emoji emoji-id="5402355073458123173">⌛️</tg-emoji> 𝚁𝚄𝙽𝚃𝙸𝙼𝙴 : ${RUNTIME}
<tg-emoji emoji-id="5992087137267225105">💻</tg-emoji> 𝚅𝙿𝚂 𝚃𝙸𝙼𝙴 : ${VPSTIME}
<tg-emoji emoji-id="5879770735999717115">👤</tg-emoji> 𝚃𝙾𝚃𝙰𝙻 𝚄𝚂𝙴𝚁 : ${totalUsers}
<tg-emoji emoji-id="5931472654660800739">📊</tg-emoji> 𝙹𝚄𝙼𝙻𝙰𝙷 𝙶𝚁𝙾𝚄𝙿 : ${totalGroups}</blockquote>
<blockquote><tg-emoji emoji-id="6165775219580472827">☠</tg-emoji> Silakan pilih menu di bawah ini untuk mulai.</blockquote>`,
          parse_mode: "HTML",
        },
        {
          chat_id: chatId,
          message_id: messageId,
          reply_markup: {
            inline_keyboard: [
              [
                { text: "𝙼𝚎𝚗𝚞 𝙾𝚠𝚗𝚎𝚛", callback_data: "menuowner", style: "danger", icon_custom_emoji_id: "5411430859045626151" }
              ],
              [
                { text: "𝙼𝚎𝚗𝚞 𝙰𝚍𝚖𝚒𝚗", callback_data: "menuadmin", style: "primary", icon_custom_emoji_id: "5411419730785369685" },
                { text: "𝙼𝚎𝚗𝚞 𝙹𝚊𝚐𝚊 𝙶𝚋", callback_data: "menujagagroup", style: "primary", icon_custom_emoji_id: "5411329291659013967" }
              ],
              [
                { text: "𝙼𝚎𝚗𝚞 𝙶𝚊𝚖𝚎𝚜", callback_data: "menugames", style: "success", icon_custom_emoji_id: "5368499186293564526" }
              ],
              [
                { text: "𝙼𝚎𝚗𝚞 𝙼𝚘𝚛𝚎", callback_data: "menumore", style: "primary", icon_custom_emoji_id: "5463343407197878047" },
                { text: "𝚃𝚚𝚝𝚘", callback_data: "tqto", style: "primary", icon_custom_emoji_id: "5408997339165653167" }
              ],
              [
                { text: "𝙲𝚑𝚊𝚗𝚗𝚎𝚕", url: "https://t.me/angkasanyabadmood", style: "danger", icon_custom_emoji_id: "5409087245716056598" }
              ],
              [
                { text: "𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛", url: "https://t.me/angkasanyabobo", style: "primary", icon_custom_emoji_id: "5463039890449003865" },
                { text: "𝙲𝚞𝚕𝚒𝚔 𝙱𝚘𝚝", url: `https://t.me/${NAMA_BOT}?startgroup=true`, style: "primary", icon_custom_emoji_id: "5463257460607315631" }
              ]
            ],
          },
        }
      );
    }

    await bot.answerCallbackQuery(query.id);
  } catch (err) {
    console.error("❌ Gagal edit pesan:", err.message);
    bot.answerCallbackQuery(query.id, { text: "Gagal memuat menu!", show_alert: true });
  }
});

//====================== FITUR OWNER MENU ===================

bot.onText(/^\/maintenance(@\w+)?\s+(on|off)$/i, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const mode = match[2].toLowerCase();

  if (!OWNER.includes(userId)) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Kamu bukan owner!</blockquote>`, {
      parse_mode: "HTML"
    })
  }

  if (mode === "on") {
    maintenanceMode = true
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5462921117423384478">🛠</tg-emoji> Maintenance Mode AKTIF</blockquote>`, {
      parse_mode: "HTML"
    })
  } else {
    maintenanceMode = false
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Maintenance Mode NONAKTIF</blockquote>`, {
      parse_mode: "HTML"
    })
  }
})

bot.onText(/^\/listuser(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!OWNER.includes(String(userId))) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Command ini hanya untuk owner.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const users = loadUsers();
  const userList = Object.values(users);

  if (userList.length === 0) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5449800250032143374">📭</tg-emoji> Tidak ada user terdaftar.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const perPage = 20;
  const totalPages = Math.ceil(userList.length / perPage);
  const page = 1;

  const start = (page - 1) * perPage;
  const end = start + perPage;
  const pageData = userList.slice(start, end);

  let text = `<blockquote><b><tg-emoji emoji-id="4958506272551863292">📊</tg-emoji> TOTAL USER:</b> ${userList.length}\n`;
  text += `<b><tg-emoji emoji-id="5256113064821926998">📄</tg-emoji> Page:</b> ${page}/${totalPages}</blockquote>\n`;

  pageData.forEach((u, i) => {
    text += `<b>${start + i + 1}.</b> ${u.first_name || "-"} `;
    if (u.username) text += `(@${u.username}) <tg-emoji emoji-id="5208748315805499400">✅</tg-emoji>`;
    text += `\n<code>ID:</code> ${u.id}\n\n`;
  });

  const buttons = [];

  if (page > 1) {
    buttons.push({
      text: "Back",
      callback_data: `listuser_${page - 1}`,
      style: "danger",
      icon_custom_emoji_id: "5258236805890710909"
    });
  }

  if (page < totalPages) {
    buttons.push({
      text: "Next",
      callback_data: `listuser_${page + 1}`,
      style: "danger",
      icon_custom_emoji_id: "5260450573768990626"
    });
  }

  bot.sendMessage(chatId, text, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [buttons]
    }
  });
});

bot.onText(/^\/listgb(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!OWNER.includes(String(userId))) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Command ini hanya untuk owner.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  sendGroupList(chatId, 1);
});

bot.on("callback_query", async (query) => {
  const data = query.data;
  const userId = query.from.id;

  if (data.startsWith("listgb_")) {

    if (!OWNER.includes(String(userId))) {
      return bot.answerCallbackQuery(query.id, {
        text: "❌ Kamu tidak punya akses!",
        show_alert: true
      });
    }

    const page = parseInt(data.split("_")[1]);

    const groups = loadGroups();
    const perPage = 15;
    const totalPages = Math.ceil(groups.length / perPage);

    let validPage = Math.min(Math.max(page, 1), totalPages);

    const start = (validPage - 1) * perPage;
    const slice = groups.slice(start, start + perPage);

    let text = `<blockquote><tg-emoji emoji-id="5931718859366075705">📂</tg-emoji> <b>DAFTAR GROUP</b></blockquote>\n`;
    text += `<blockquote><tg-emoji emoji-id="5033080906403808074">📝</tg-emoji> Page ${validPage}/${totalPages}</blockquote>\n\n`;

    slice.forEach((g, i) => {
      text += `<b>${start + i + 1}.</b> ${g.title}\n`;
      text += `<code>${g.id}</code>\n`;
    });

    text += `\n<blockquote><tg-emoji emoji-id="5319169695897632605">💃</tg-emoji> <b>Total Group:</b> ${groups.length}</blockquote>`;

    let keyboard = { inline_keyboard: [] };
    let row = [];

    if (validPage > 1) {
      row.push({
        text: "Back",
        callback_data: `listgb_${validPage - 1}`,
        style: "danger",
        icon_custom_emoji_id: "5258236805890710909"
      });
    }

    if (validPage < totalPages) {
      row.push({
        text: "Next",
        callback_data: `listgb_${validPage + 1}`,
        style: "danger",
        icon_custom_emoji_id: "5260450573768990626"
      });
    }

    if (row.length) keyboard.inline_keyboard.push(row);

    await bot.editMessageText(text, {
      chat_id: query.message.chat.id,
      message_id: query.message.message_id,
      parse_mode: "HTML",
      reply_markup: keyboard
    });

    bot.answerCallbackQuery(query.id);
  }
});

bot.onText(/^\/backup(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (senderId != OWNER) {
    return bot.sendMessage(
      chatId,
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> <b>Hanya owner yang bisa menggunakan fitur ini.</b></blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const loadingMsg = await bot.sendMessage(
    chatId,
    `<blockquote><tg-emoji emoji-id="5296778528145022661">⏳</tg-emoji> <b>Memulai proses backup...</b></blockquote>`,
    { parse_mode: "HTML" }
  );

  let dots = 0;
  const loadingInterval = setInterval(() => {
    dots = (dots + 1) % 4;

    bot.editMessageText(
      `<blockquote><tg-emoji emoji-id="5296778528145022661">⏳</tg-emoji> <b>Membackup file${".".repeat(dots)}</b></blockquote>`,
      {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
        parse_mode: "HTML"
      }
    ).catch(() => {});
  }, 800);

  const sourceDir = __dirname;
  const backupName = `BACKUP SCRIPT MD V${VERSION} BY ANGKASA.zip`;
  const outputPath = require("path").join(__dirname, backupName);

  const output = require("fs").createWriteStream(outputPath);
  const archive = require("archiver")("zip", { zlib: { level: 9 } });

  archive.pipe(output);

  archive.glob("**/*", {
    cwd: sourceDir,
    ignore: [
      "node_modules/**",
      "package-lock.json",
      ".cache/**",
      ".npm/**",
      backupName
    ]
  });

  await archive.finalize();

  output.on("close", async () => {
    clearInterval(loadingInterval);

    const now = new Date();

    const tanggal = now.toLocaleDateString("id-ID", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    });

    const getTime = (offset) =>
      new Date(now.getTime() + offset * 60 * 60 * 1000)
        .toTimeString()
        .split(" ")[0];

    const caption = `
<blockquote><b><tg-emoji emoji-id="5256094480498436162">📦</tg-emoji> BACKUP</b>

<tg-emoji emoji-id="5413879192267805083">📅</tg-emoji> <b>${tanggal}</b>

<tg-emoji emoji-id="5778605968208170641">🕒</tg-emoji> <b>WIB</b>  : ${getTime(7)}
<tg-emoji emoji-id="5778605968208170641">🕒</tg-emoji> <b>WITA</b> : ${getTime(8)}
<tg-emoji emoji-id="5778605968208170641">🕒</tg-emoji> <b>WIT</b>  : ${getTime(9)}

<tg-emoji emoji-id="5258514780469075716">📁</tg-emoji> <b>Size</b> : ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB
</blockquote>`;

    await bot.sendDocument(OWNER[0], outputPath, {
      caption,
      parse_mode: "HTML"
    });

    await bot.editMessageText(
      `<blockquote><tg-emoji emoji-id="6334525098820636632">✅</tg-emoji> <b>Backup berhasil dikirim ke private owner.</b></blockquote>`,
      {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
        parse_mode: "HTML"
      }
    ).catch(() => {});

    require("fs").unlinkSync(outputPath);
  });
});

bot.onText(/^\/bc$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!OWNER.includes(String(userId))) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="4958526153955476488">❌</tg-emoji> Hanya owner yang bisa menggunakan broadcast.</blockquote>`, { parse_mode: "HTML" });
  }

  if (broadcastInProgress[userId]) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="4958526153955476488">❌</tg-emoji> Broadcast sebelumnya masih berjalan, tunggu sampai selesai.</blockquote>`, { parse_mode: "HTML" });
  }

  broadcastState[userId] = { step: 'choose_type' };
  
  const options = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: "User", callback_data: "broadcast_user", style : "primary", icon_custom_emoji_id: "5319287627109644494" },
          { text: "Group", callback_data: "broadcast_group", style : "primary", icon_custom_emoji_id: "5318942831430090639" }
        ],
        [
          { text: "All", callback_data: "broadcast_all", style : "success", icon_custom_emoji_id: "5316743524706698146" }
        ],
        [
          { text: "Batal", callback_data: "broadcast_cancel", style : "danger", icon_custom_emoji_id: "4956612582816351459" }
        ]
      ]
    }
  };

  bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269459131720012969">📣</tg-emoji> Pilih target broadcast:</blockquote>`, {
    ...options,
    parse_mode: "HTML"
  });
});

bot.on('callback_query', (query) => {
  const userId = query.from.id;
  const chatId = query.message.chat.id;
  const data = query.data;

  if (!data.startsWith("broadcast_")) return;

  if (!OWNER.includes(String(userId))) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Hanya owner yang bisa menggunakan broadcast.",
      show_alert: true
    });
  }

  if (data === "broadcast_cancel") {
    delete broadcastState[userId];
    return bot.editMessageText(
      `<blockquote><tg-emoji emoji-id="4958526153955476488">❌</tg-emoji> Broadcast dibatalkan.</blockquote>`,
      {
        chat_id: chatId,
        message_id: query.message.message_id,
        parse_mode: "HTML"
      }
    );
  }

  if (!broadcastState[userId] || broadcastState[userId].step !== 'choose_type') return;

  let type;
  if (data === "broadcast_user") type = "user";
  else if (data === "broadcast_group") type = "group";
  else if (data === "broadcast_all") type = "all";

  broadcastState[userId].type = type;
  broadcastState[userId].step = 'await_message';

  bot.answerCallbackQuery(query.id, { text: "✅ Pilihan diterima" });

  bot.editMessageText(
    `<blockquote><tg-emoji emoji-id="5215209935188534658">✏️</tg-emoji> Kirim teks atau forward pesan yang ingin di-broadcast:</blockquote>`,
    {
      chat_id: chatId,
      message_id: query.message.message_id,
      parse_mode: "HTML"
    }
  );
});

bot.on('message', async (msg) => {
  const userId = msg.from.id;

  if (!OWNER.includes(String(userId))) return;
  if (!broadcastState[userId] || broadcastState[userId].step !== 'await_message') return;

  if (broadcastInProgress[userId]) return;
  broadcastInProgress[userId] = true;

  const type = broadcastState[userId].type;
  const content = msg;
  const chatId = msg.chat.id;

  let targets = [];
    if (type === "user") {
      targets = Object.keys(loadUsers());
    } else if (type === "group") {
      targets = loadGroups().map(g => g.id);
    } else if (type === "all") {
      const users = Object.keys(loadUsers());
      const groups = loadGroups().map(g => g.id);
      targets = [...users, ...groups];
    }
  const total = targets.length;
  let success = 0;
  let failed = 0;

  const statusMsg = await bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5454415424319931791">⏳</tg-emoji> Broadcast dimulai...\nTotal target: <b>${total}</b>\nBerhasil: 0\nGagal: 0</blockquote>`, { 
    parse_mode: "HTML"
  });

  for (let i = 0; i < targets.length; i++) {
    const id = targets[i];
    try {
      await bot.forwardMessage(id, chatId, content.message_id);
      success++;
    } catch (err) {
      failed++;
      console.log(`Failed to send to ${id}: ${err.message}`);
    }

    if ((i + 1) % 5 === 0 || i === targets.length - 1) {
      await bot.editMessageText(`<blockquote><tg-emoji emoji-id="5454415424319931791">⏳</tg-emoji> Broadcast dimulai...\nTotal target: <b>${total}</b>\nBerhasil: <b>${success}</b>\nGagal: <b>${failed}</b></blockquote>`, {
        chat_id: chatId,
        message_id: statusMsg.message_id,
        parse_mode: "HTML"
      });
    }
  }

  bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5936067938955039275">✅</tg-emoji> Broadcast selesai!</blockquote>`, {
    parse_mode: "HTML"
  });

  delete broadcastState[userId];
  broadcastInProgress[userId] = false;
});

//====================== FITUR ADMIN MENU ===================

bot.onText(/^\/link(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Perintah ini hanya bisa digunakan di dalam group.</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  try {
    const member = await bot.getChatMember(chatId, userId);

    if (!["administrator", "creator"].includes(member.status)) {
      return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Hanya admin yang bisa menggunakan perintah ini.</blockquote>`, {
        parse_mode: "HTML"
      });
    }

  } catch (err) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal mengecek status admin.</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  if (!match[1]) {
    return bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="5215441850537618106">🔗</tg-emoji> Fitur Private Link</blockquote>
<blockquote>Cara pakai:
/link @username
/link @username 10
/link id
/link id 10

Contoh:
/link @angkasanyabobo 5
/link 1979197817 3
Keterangan:
• Angka terakhir = durasi expired (menit)
• Default = 5 menit
• Link hanya bisa dipakai 1 orang
• Otomatis terhapus setelah digunakan</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const args = match[1].split(" ");
  const target = args[0].replace("@", "");
  const minutes = parseInt(args[1]) || 5;

  const expireDate = Math.floor(Date.now() / 1000) + (minutes * 60);

  try {
    const invite = await bot.createChatInviteLink(chatId, {
      member_limit: 1,
      expire_date: expireDate
    });

    activeLinks[invite.invite_link] = {
      target,
      chatId,
      expireAt: Date.now() + (minutes * 60 * 1000)
    };

    bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="5215441850537618106">🔗</tg-emoji> <b>Link untuk ${target}</b>\n` +
      `<tg-emoji emoji-id="5258258882022612173">⏳</tg-emoji> Expired ${minutes} menit\n\n` +
      `<code>${invite.invite_link}</code></blockquote>`,
      { parse_mode: "HTML" }
    );

  } catch (err) {
    console.log(err);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat link.</blockquote>`, {
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/pin$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  const adminsGroup = await bot.getChatAdministrators(chatId);
  const isAdminGroup = adminsGroup.some(a => a.user.id === userId);
  if (userId !== OWNER && !isAdminGroup) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Hanya Admin Grup & Owner yang bisa memakai perintah ini.</blockquote>`, { parse_mode: "HTML" });
  }

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Reply pesan yang mau di-pin lalu ketik /pin.</blockquote>`, { parse_mode: "HTML" });
  }

  try {
    await bot.pinChatMessage(chatId, msg.reply_to_message.message_id);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Pesan berhasil di-pin!</blockquote>`, { parse_mode: "HTML" });
  } catch (error) {
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Gagal pin: ${error.message}</blockquote>`, { parse_mode: "HTML" });
  }
});

bot.onText(/^\/unpin$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  const adminsGroup = await bot.getChatAdministrators(chatId);
  const isAdminGroup = adminsGroup.some(a => a.user.id === userId);

  if (userId !== OWNER && !isAdminGroup) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Hanya Admin Grup & Owner yang bisa memakai perintah ini.</blockquote>`, { parse_mode: "HTML" });
  }

  try {
    await bot.unpinChatMessage(chatId);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Pin berhasil dilepas!</blockquote>`, { parse_mode: "HTML" });
  } catch (error) {
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Gagal unpin: ${error.message}</blockquote>`, { parse_mode: "HTML" });
  }
});

bot.onText(/^\/mute(?:\s+([\w@]+))?(?:\s+(\d+[smhd]))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  let targetArg = match[1];
  let durationArg = match[2];
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (targetArg && /^\d+[smhd]$/i.test(targetArg)) {
    durationArg = targetArg;
    targetArg = null;
  }

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);
  if (!isAdmin) {
    return bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh menggunakan command ini.</blockquote>`, 
      { parse_mode: "HTML" }
    );
  }

  let targetId = null;
  let targetName = "User";

  if (msg.reply_to_message) {    targetId = msg.reply_to_message.from.id;
    targetName = msg.reply_to_message.from.first_name;
  } 

  else if (targetArg) {
    if (targetArg.startsWith('@')) {
      try {
        const chat = await bot.getChat(targetArg);
        targetId = chat.id;
        targetName = chat.first_name || chat.username;
      } catch (e) {
        return bot.sendMessage(chatId, 
          `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> User tidak ditemukan.</blockquote>`, 
          { parse_mode: "HTML" }
        );
      }
    } else {
      targetId = targetArg;
    }
  }

  if (!targetId) {
    return bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Reply pesan user atau sertakan username/ID.\n\nContoh: <code>/mute @username 5m</code> atau <code>/mute 10s</code> (reply)</blockquote>`, 
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    );
  }

  try {
    const member = await bot.getChatMember(chatId, targetId);
    if (member.status === 'administrator' || member.status === 'creator') {
      return bot.sendMessage(chatId, 
        `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Tidak bisa mute admin atau creator grup.</blockquote>`, 
        { parse_mode: "HTML" }
      );
    }

    const duration = parseDuration(durationArg);
    const untilDate = duration > 0 ? Math.floor(Date.now() / 1000) + duration : undefined;

    await bot.restrictChatMember(chatId, targetId, {
      can_send_messages: false,
      can_send_media_messages: false,
      can_send_polls: false,
      can_send_other_messages: false,
      can_add_web_page_previews: false,
      can_change_info: false,
      can_invite_users: false,      can_pin_messages: false
    }, { until_date: untilDate });

    const durationText = durationArg ? `selama <b>${durationArg}</b>` : `secara permanen`;
    
    bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="6269243378332864932">🔇</tg-emoji> <b>${targetName}</b> telah di-mute ${durationText}.</blockquote>`, 
      { parse_mode: "HTML" }
    );

  } catch (err) {
    console.error("Mute Error:", err);
    bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal melakukan mute: ${err.message || err}</blockquote>`, 
      { parse_mode: "HTML" }
    );
  }
});

bot.onText(/^\/unmute(?:\s+([\w@]+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const targetArg = match[1];
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);
  if (!isAdmin) {
    return bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh menggunakan command ini.</blockquote>`, 
      { parse_mode: "HTML" }
    );
  }

  let targetId = null;
  let targetName = "User";

  if (msg.reply_to_message) {
    targetId = msg.reply_to_message.from.id;
    targetName = msg.reply_to_message.from.first_name;
  } else if (targetArg) {
    if (targetArg.startsWith('@')) {
      try {
        const chat = await bot.getChat(targetArg);
        targetId = chat.id;
        targetName = chat.first_name || chat.username;
      } catch (e) {        return bot.sendMessage(chatId, 
          `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> User tidak ditemukan.</blockquote>`, 
          { parse_mode: "HTML" }
        );
      }
    } else {
      targetId = targetArg;
    }
  }

  if (!targetId) {
    return bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Reply pesan user atau sertakan username/ID.\n\nContoh: <code>/unmute @username</code></blockquote>`, 
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    );
  }

  try {
    await bot.restrictChatMember(chatId, targetId, {
      can_send_messages: true,
      can_send_media_messages: true,
      can_send_polls: true,
      can_send_other_messages: true,
      can_add_web_page_previews: true,
      can_change_info: false,
      can_invite_users: true,
      can_pin_messages: false
    });

    bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="6269243378332864932">🔊</tg-emoji> <b>${targetName}</b> telah di-unmute.</blockquote>`, 
      { parse_mode: "HTML" }
    );

  } catch (err) {
    console.error("Unmute Error:", err);
    bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal melakukan unmute: ${err.message || err}</blockquote>`, 
      { parse_mode: "HTML" }
    );
  }
});

bot.onText(/^\/promote(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const title = match[1] ? match[1].trim() : null;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Perintah ini hanya bisa digunakan di grup.</blockquote>`, {
    parse_mode: "HTML"
    });
  }

  try {

    const admins = await bot.getChatAdministrators(chatId);
    const isAdmin = admins.some(admin => admin.user.id === senderId);

    if (!isAdmin) {
      return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Hanya admin grup yang bisa menggunakan perintah ini.</blockquote>`, {
      parse_mode: "HTML"
      });
    }

    if (!msg.reply_to_message) {
      return bot.sendMessage(
        chatId,
        `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Reply pesan user yang ingin dipromote.\nContoh: /promote MODERATOR</blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    const target = msg.reply_to_message.from;

    await bot.promoteChatMember(chatId, target.id, {
      can_change_info: true,
      can_post_messages: true,
      can_edit_messages: true,
      can_delete_messages: true,
      can_invite_users: true,
      can_restrict_members: true,
      can_pin_messages: true,
      can_promote_members: false,
    });

    if (title) {
      await bot.setChatAdministratorCustomTitle(chatId, target.id, title);
    }

    bot.sendMessage(
      chatId,
      `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> User <b>${target.first_name}</b> sudah dipromote jadi admin${title ? ` dengan gelar <b>${title}</b>` : ""}.</blockquote>`, { 
      parse_mode: "HTML" 
      });
  } catch (err) {
    console.error("[PROMOTE ERROR]", err);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Gagal promote user. Pastikan bot admin dan punya izin cukup.</blockquote>`, {
    parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/demote$/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Perintah ini hanya bisa digunakan di grup.</blockquote>`, {
    parse_mode: "HTML"
    });
  }

  try {

    const admins = await bot.getChatAdministrators(chatId);
    const isAdmin = admins.some(admin => admin.user.id === senderId);

    if (!isAdmin) {
      return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Hanya admin grup yang bisa menggunakan perintah ini.</blockquote>`, {
      parse_mode: "HTML"
      });
    }

    if (!msg.reply_to_message) {
      return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Reply pesan user yang ingin didemote.</blockquote>`, {
      parse_mode: "HTML"
      });
    }

    const target = msg.reply_to_message.from;

    await bot.promoteChatMember(chatId, target.id, {
      can_change_info: false,
      can_post_messages: false,
      can_edit_messages: false,
      can_delete_messages: false,
      can_invite_users: false,
      can_restrict_members: false,
      can_pin_messages: false,
      can_promote_members: false,
    });

    bot.sendMessage(
      chatId,
      `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> User <b>${target.first_name}</b> sudah didemote dari admin.</blockquote>`,{
      parse_mode: "HTML"
      });
  } catch (err) {
    console.error("[DEMOTE ERROR]", err);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5805345674383855340">🚫</tg-emoji> Gagal demote user. Pastikan bot admin dan punya izin cukup.</blockquote>`, {
    parse_mode: "HTML"
    });
  }
});

bot.onText(/\/setwelcome(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;
  
  if (!msg.chat.type.includes("group")) return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya untuk grup.</blockquote>`, { 
    parse_mode: "HTML" });
    
  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(x => x.user.id === senderId);
  
  if (!isAdmin) return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang bisa set welcome.</blockquote>`, { 
    parse_mode: "HTML" });
    
  const text = msg.text.split(" ").slice(1).join(" ");
  
  if (!text) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Format salah!\nGunakan:\n/setwelcome Selamat datang @name di @group jam @time</blockquote>`, { 
    parse_mode: "HTML" });
  }
  
  const data = getGroupMessages();
  
  data[chatId] = data[chatId] || {};
  data[chatId].welcome = text;
  saveGroupMessages(data);
  bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Pesan welcome berhasil disimpan.</blockquote>`, { 
    parse_mode: "HTML" });
});

bot.onText(/\/setleft(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;
  
  if (!msg.chat.type.includes("group")) return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya untuk grup.</blockquote>`, { 
    parse_mode: "HTML" });
    
  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(x => x.user.id === senderId);
  
  if (!isAdmin) return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang bisa set left.</blockquote>`, { 
    parse_mode: "HTML" });
    
  const text = msg.text.split(" ").slice(1).join(" ");
  
  if (!text) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Format salah!\nGunakan:\n/setleft Selamat tinggal @name dari @group jam @time</blockquote>`, { 
    parse_mode: "HTML" });
  }
  
  const data = getGroupMessages();
  data[chatId] = data[chatId] || {};
  data[chatId].left = text;
  saveGroupMessages(data);
  bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Pesan left berhasil disimpan.</blockquote>`, { 
    parse_mode: "HTML" });
});

bot.onText(/\/setpic\s+(welcome|left)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const type = match[1].toLowerCase();
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!msg.chat.type.includes("group")) return;
  const admins = await bot.getChatAdministrators(chatId);
  if (!admins.some(x => x.user.id === senderId)) return;

  const reply = msg.reply_to_message;
  if (!reply || !reply.photo) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Reply ke foto yang ingin dijadikan ${type} pic.</blockquote>`, { parse_mode: "HTML" });
  }

  const photo = reply.photo.pop();
  const fileId = photo.file_id;

  const data = getGroupMessages();
  data[chatId] = data[chatId] || {};

  if (type === "welcome") data[chatId].welcomePhoto = fileId;
  else if (type === "left") data[chatId].leftPhoto = fileId;

  saveGroupMessages(data);
  bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Foto ${type} berhasil disimpan!</blockquote>`, { parse_mode: "HTML" });
});

bot.onText(/\/setcontact(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!msg.chat.type.includes("group")) return;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  if (!admins.some(x => x.user.id === senderId)) return;

  const input = match[1];
  if (!input || !input.includes("|")) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Format salah!\nGunakan:\n/setcontact NamaTombol|https://link.com</blockquote>`, { parse_mode: "HTML" });
  }

  const [text, url] = input.split("|").map(s => s.trim());
  const data = getGroupMessages();
  data[chatId] = data[chatId] || {};
  data[chatId].contactButton = { text, url };
  saveGroupMessages(data);

  bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Tombol welcome & left berhasil disimpan: ${text} → ${url}</blockquote>`, { parse_mode: "HTML" });
});

bot.onText(/\/setcn(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!msg.chat.type.includes("group")) return;
  const admins = await bot.getChatAdministrators(chatId);
  if (!admins.some(x => x.user.id === senderId)) return;

  const text = match[1];
  if (!text) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Format salah!\nGunakan:\n/setcn SR ||</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const data = getGroupMessages();
  data[chatId] = data[chatId] || {};
  data[chatId].copyButton = text;
  saveGroupMessages(data);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Tombol CN berhasil disimpan: <b>${text}</b></blockquote>`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/\/settime (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const val = Number(match[1]);
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!msg.chat.type.includes("group")) return;
  const admins = await bot.getChatAdministrators(chatId);
  if (!admins.some(x => x.user.id === senderId)) return;

  const buttons = {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Detik", callback_data: `time_s_${val}`, style : "success", icon_custom_emoji_id: "5213349767672769194" }
        ],
        [
          { text: "Menit", callback_data: `time_m_${val}`, style : "success", icon_custom_emoji_id: "5213349767672769194" }
        ],
        [
          { text: "Jam", callback_data: `time_h_${val}`, style : "success", icon_custom_emoji_id: "5213349767672769194" }
        ]
      ]
    }
  };

  bot.sendMessage(chatId, `Pilih satuan waktu untuk ${val}`, {
    parse_mode: "HTML",
    ...buttons
  });
});

bot.on("callback_query", (cb) => {
  const chatId = cb.message.chat.id;
  const data = cb.data;

  if (!data.startsWith("time_")) return;

  const [_, type, num] = data.split("_");
  let ms = 0;

  if (type === "s") ms = num * 1000;
  if (type === "m") ms = num * 60 * 1000;
  if (type === "h") ms = num * 60 * 60 * 1000;

  const groups = getGroupMessages();
  groups[chatId] = groups[chatId] || {};
  groups[chatId].cnTime = ms;
  saveGroupMessages(groups);

  bot.editMessageText(
    `<blockquote><tg-emoji emoji-id="5454415424319931791">⏳</tg-emoji> *CN Timeout diset:* ${num} ${type === "s" ? "detik" : type === "m" ? "menit" : "jam"}</blockquote>`,
    {
      chat_id: chatId,
      message_id: cb.message.message_id,
      parse_mode: "HTML"
    }
  );
});

bot.onText(/^\/filter(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const args = match[1];
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!args) {
    return bot.sendMessage(chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> Format salah! Contoh: /filter keyword balasannya</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const parts = args.split(" ");
  const keyword = parts.shift().toLowerCase();
  const responseText = parts.join(" ") || " ";

  const filters = loadFilters();
  if (!filters[chatId]) filters[chatId] = {};

  let fileData = null;

  if (msg.reply_to_message) {
    const r = msg.reply_to_message;

    if (r.photo) {
      fileData = { type: "photo", file_id: r.photo[r.photo.length - 1].file_id };
    } else if (r.video) {
      fileData = { type: "video", file_id: r.video.file_id };
    } else if (r.document) {
      fileData = { type: "document", file_id: r.document.file_id };
    } else if (r.sticker) {
      fileData = { type: "sticker", file_id: r.sticker.file_id };
    }
  }

  filters[chatId][keyword] = {
    text: responseText,
    file: fileData
  };

  saveFilters(filters);

  bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Filter ${keyword} berhasil ditambahkan!</blockquote>`, { parse_mode: "HTML" });
});

bot.onText(/^\/listfilter$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;
  
  sendFilterPage(chatId, 1);
});

bot.onText(/^\/open$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);
  if (!isAdmin) {
    return bot.sendMessage(chatId, '<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang bisa membuka grup.</blockquote>', {
      parse_mode: "HTML"
    });
  }

  try {
    await bot.setChatPermissions(chatId, {
      can_send_messages: true,
      can_send_media_messages: true,
      can_send_polls: true,
      can_send_other_messages: true,
      can_add_web_page_previews: true,
      can_change_info: false,
      can_invite_users: true,
      can_pin_messages: false
    });

    bot.sendMessage(chatId, '<blockquote><tg-emoji emoji-id="4974606326828107003">🔓</tg-emoji> Grup telah dibuka. Semua member bisa mengirim pesan.</blockquote>', {
      parse_mode: "HTML"
    });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuka grup: ${err.message}</blockquote>`, {
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/close$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);
  if (!isAdmin) {
    return bot.sendMessage(chatId, '<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang bisa menutup grup.</blockquote>', {
      parse_mode: "HTML"
    });
  }

  try {
    await bot.setChatPermissions(chatId, {
      can_send_messages: false,
      can_send_media_messages: false,
      can_send_polls: false,
      can_send_other_messages: false,
      can_add_web_page_previews: false,
      can_change_info: false,
      can_invite_users: true,
      can_pin_messages: false
    });

    bot.sendMessage(chatId, '<blockquote><tg-emoji emoji-id="4974606326828107003">🔒</tg-emoji> Grup telah ditutup. Hanya admin yang bisa mengirim pesan.</blockquote>', {
      parse_mode: "HTML"
    });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal menutup grup: ${err.message}</blockquote>`, {
      parse_mode: "HTML"
    });
  }
});

//====================== FITUR JAGA GROUP ===================

bot.onText(/^\/antilink (on|off)$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);
  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const option = match[1].toLowerCase();
  let settings = getSettings();

  if (!settings[chatId]) settings[chatId] = {};
  settings[chatId].antilink = option === "on";

  saveSettings(settings);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> AntiLink berhasil ${option}</blockquote>`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/^\/antiforward (on|off)$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);
  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const option = match[1].toLowerCase();
  let settings = getSettings();

  if (!settings[chatId]) settings[chatId] = {};
  settings[chatId].antiforward = option === "on";

  saveSettings(settings);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> AntiForward berhasil ${option}</blockquote>`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/^\/antifoto (on|off)$/i, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  const admins = await bot.getChatAdministrators(chatId);
  const isAdmin = admins.some(a => a.user.id === userId);
  if (!isAdmin) return bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Hanya admin yang boleh mengubah setting.</blockquote>`,
    { parse_mode: "HTML" }
  );

  const option = match[1].toLowerCase();
  let settings = getSettings();

  if (!settings[chatId]) settings[chatId] = {};
  settings[chatId].antifoto = option === "on";

  saveSettings(settings);

  bot.sendMessage(chatId,
    `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> AntiFoto berhasil ${option}</blockquote>`,
    { parse_mode: "HTML" }
  );
});

//================== FITUR GAMES ================

bot.onText(/^\/top(@\w+)?$/, (msg) => {
  const chatId = msg.chat.id;
  const users = loadUsers();

  const ranking = Object.values(users)
    .map(user => {
      const wins = user.wins || 0;
      const losses = user.losses || 0;
      const draws = user.draws || 0;
      const total = wins + losses + draws;

      return {
        name: escapeHtml(user.first_name || "No Name"),
        wins,
        losses,
        draws,
        total
      };
    })
    .filter(u => u.total > 0)
    .sort((a, b) => b.wins - a.wins)
    .slice(0, 10);

  if (ranking.length === 0) {
    return bot.sendMessage(chatId, "Belum ada data pertandingan.");
  }

  let text = `<blockquote><b><tg-emoji emoji-id="5789828777882162072">🏆</tg-emoji> TOP 10 DADU</b></blockquote>\n`;

  ranking.forEach((user, index) => {
    text += `<blockquote><b>${index + 1}. ${user.name}</b></blockquote>\n`;
    text += `<tg-emoji emoji-id="5848075728486143781">🏆</tg-emoji> Win  : ${user.wins}\n`;
    text += `<tg-emoji emoji-id="5400250414929041085">⚖️</tg-emoji> Seri : ${user.draws}\n`;
    text += `<tg-emoji emoji-id="4956612582816351459">❌</tg-emoji> Lose : ${user.losses}\n`;
  });

  bot.sendMessage(chatId, text, { parse_mode: "HTML" });
});

bot.onText(/^\/dadu(?:\s+@(\w+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;
  
  if (msg.chat.type === "private") return;

  const challenger = msg.from;
  let opponent = null;

  if (msg.reply_to_message) {
    opponent = msg.reply_to_message.from;
  }

  else if (match[1]) {
    const username = match[1].toLowerCase();
    const usersDB = loadUsers();

  const foundUser = Object.values(usersDB).find(
    u => u.username && u.username.toLowerCase() === username
  );

  if (foundUser) {
      opponent = foundUser;
    } else {
      return bot.sendMessage(
        chatId,
        `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> User belum terdaftar.\n\nSuruh dia /start bot di private dulu.</blockquote>`,
        { parse_mode: "HTML" }
      );
    }
  }

  if (!opponent) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Reply pesan target atau gunakan /dadu @username</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  if (challenger.id === opponent.id) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Tidak bisa melawan diri sendiri.</blockquote>`, {
      parse_mode: "HTML"
    });
  }

  const gameId = Date.now().toString();

  activeDiceGames[gameId] = {
    chatId,
    player1: challenger,
    player2: opponent,
    status: "waiting",
    choices: {}
  };

  const sentMsg = await bot.sendMessage(
    chatId,
    `<blockquote><tg-emoji emoji-id="5231055860544855669">🎲</tg-emoji> TANTANGAN DADU</blockquote>

<tg-emoji emoji-id="4967667085606912536">👤</tg-emoji> ${challenger.first_name} menantang ${opponent.first_name}

<blockquote>${opponent.first_name}, tekan tombol TERIMA untuk mulai!</blockquote>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "TERIMA",
              callback_data: `terima_${gameId}`,
              style: "success",
              icon_custom_emoji_id: "5208748315805499400"
            }
          ],
          [
            {
              text: "BATAL",
              callback_data: `batal_${gameId}`,
              style: "danger",
              icon_custom_emoji_id: "4956612582816351459"
            }
          ]
        ]
      }
    }
  );

  activeDiceGames[gameId].groupMessageId = sentMsg.message_id;
});

bot.on("callback_query", async (query) => {
  const data = query.data;
  if (!data) return;

  if (data.startsWith("terima_")) {
    const gameId = data.split("_")[1];
    const game = activeDiceGames[gameId];
    if (!game) return;

    if (query.from.id !== game.player2.id) {
      return bot.answerCallbackQuery(query.id, {
        text: "Kamu bukan yang ditantang!",
        show_alert: true
      });
    }

    if (game.status !== "waiting") {
      return bot.answerCallbackQuery(query.id, {
        text: "Game sudah dimulai!"
      });
    }

    game.status = "accepted";

    await bot.answerCallbackQuery(query.id, {
      text: "Tantangan diterima! 🎲"
    });

    await bot.editMessageText(`<blockquote><tg-emoji emoji-id="6298630163047387557">🔥</tg-emoji> ${game.player2.first_name} menerima tantangan!</blockquote>
<blockquote><tg-emoji emoji-id="5411465631100850183">📩</tg-emoji> Tekan MULAI untuk lanjut atau TANDING ULANG.</blockquote>`,
      {
        chat_id: game.chatId,
        message_id: game.groupMessageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "MULAI", callback_data: `mulai_${gameId}`, style: "success", icon_custom_emoji_id: "5208748315805499400" }
            ],
            [
              { text: "TANDING ULANG", callback_data: `ulang_${gameId}`, style: "primary", icon_custom_emoji_id: "5274156304036800055" }
            ]
          ]
        }
      }
    );
  }
  
  if (data.startsWith("batal_")) {
    const gameId = data.split("_")[1];
    const game = activeDiceGames[gameId];
    if (!game) return;

    if (query.from.id !== game.player1.id) {
      return bot.answerCallbackQuery(query.id, {
        text: "Hanya penantang yang bisa membatalkan!",
        show_alert: true
      });
    }

    if (game.status !== "waiting") {
      return bot.answerCallbackQuery(query.id, {
        text: "Game sudah berjalan!"
      });
    }

    await bot.editMessageText(
      `<blockquote><tg-emoji emoji-id="4956612582816351459">❌</tg-emoji> Tantangan dibatalkan oleh ${game.player1.first_name}</blockquote>`,
      {
        chat_id: game.chatId,
        message_id: game.groupMessageId,
        parse_mode: "HTML"
      }
    );

    delete activeDiceGames[gameId];

    return bot.answerCallbackQuery(query.id);
  }
  
  if (data.startsWith("ulang_")) {
    const gameId = data.split("_")[1];
    const game = activeDiceGames[gameId];
    if (!game) return;
    
    if (query.from.id !== game.player1.id &&
      query.from.id !== game.player2.id) {
    return bot.answerCallbackQuery(query.id, {
      text: "Bukan game kamu!",
      show_alert: true
    });
  }

    game.status = "waiting";
    game.choices = {};

    await bot.editMessageText(`<blockquote><tg-emoji emoji-id="5373310679241466020">🔄</tg-emoji> Tantangan direset!</blockquote>
<blockquote><tg-emoji emoji-id="5208748315805499400">✅</tg-emoji> ${game.player2.first_name}, tekan TERIMA untuk mulai lagi!</blockquote>`,
      {
        chat_id: game.chatId,
        message_id: game.groupMessageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "TERIMA", callback_data: `terima_${gameId}`, style: "success", icon_custom_emoji_id: "5231055860544855669" }
            ],
            [
              { text: "BATAL", callback_data: `batal_${gameId}`, style: "danger", icon_custom_emoji_id: "4956612582816351459" }
            ]
          ]
        }
      }
    );

    return bot.answerCallbackQuery(query.id);
  }
  
  if (data.startsWith("mulai_")) {
    const gameId = data.split("_")[1];
    const game = activeDiceGames[gameId];
    if (!game) return;
  
    if (game.status !== "accepted") {
      return bot.answerCallbackQuery(query.id, {
        text: "Game belum siap!"
      });
    }

    game.status = "playing";

    await bot.editMessageText(`<blockquote><tg-emoji emoji-id="6269398018630357834">🎲</tg-emoji> Game dimulai!</blockquote>
<blockquote><tg-emoji emoji-id="6188301270781004357">🥰</tg-emoji> Silakan cek private chat untuk pilih dadu.</blockquote>`,
      {
        chat_id: game.chatId,
        message_id: game.groupMessageId,
        parse_mode: "HTML"
      }
    );

    sendPrivateDice(gameId, game.player1);
    sendPrivateDice(gameId, game.player2);

    return bot.answerCallbackQuery(query.id);
  }

  if (data.startsWith("dadu_")) {
    const [_, gameId, number] = data.split("_");
    const game = activeDiceGames[gameId];
    if (!game) return;

    const userId = query.from.id;

    if (userId !== game.player1.id && userId !== game.player2.id) {
      return bot.answerCallbackQuery(query.id, {
        text: "Bukan game kamu!",
        show_alert: true
      });
    }

    if (game.choices[userId]) {
      return bot.answerCallbackQuery(query.id, {
        text: "Sudah memilih!"
      });
    }
    
    if (game.status !== "playing") {
      return bot.answerCallbackQuery(query.id, {
        text: "Game belum dimulai!",
        show_alert: false
      });
    }

    game.choices[userId] = Number(number);

    await bot.answerCallbackQuery(query.id, {
      text: "Pilihan dikunci 🎲"
    });

    await bot.editMessageText(
      `<blockquote><tg-emoji emoji-id="5231055860544855669">🎲</tg-emoji> Pilihan sudah dikunci!</blockquote>`,
      {
        chat_id: query.message.chat.id,
        message_id: query.message.message_id,
        parse_mode: "HTML"
      }
    );

    if (
      game.choices[game.player1.id] &&
      game.choices[game.player2.id]
    ) {
      finishGame(gameId);
    }
  }
});

async function sendPrivateDice(gameId, user) {
  const angka = [1,2,3,4,5,6];
  angka.sort(() => Math.random() - 0.5);

  const buttons = angka.map(num => ({
    text: "?",
    callback_data: `dadu_${gameId}_${num}`,
    style: "primary",
    icon_custom_emoji_id: "5231055860544855669"
  }));

  const keyboard = [];
  while (buttons.length) keyboard.push(buttons.splice(0,3));

  try {
    await bot.sendMessage(
      user.id,
      `<blockquote><tg-emoji emoji-id="5287734473775918473">🔼</tg-emoji> Pilih salah satu dadu:</blockquote>`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: keyboard
        }
      }
    );
  } catch (err) {
    console.log("Gagal kirim DM ke", user.id, err.response?.body);

    await bot.sendMessage(
      activeDiceGames[gameId].chatId,
      `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> ${user.first_name} belum memulai bot.</blockquote>
<blockquote>Silakan klik bot lalu tekan /start dulu.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }
}

function finishGame(gameId) {
  const game = activeDiceGames[gameId];
  if (!game) return;

  const users = loadUsers();

  const p1 = game.player1;
  const p2 = game.player2;

  const roll1 = game.choices[p1.id];
  const roll2 = game.choices[p2.id];

  let result;

  if (!users[p1.id]) return;
  if (!users[p2.id]) return;

  users[p1.id].wins ??= 0;
  users[p1.id].losses ??= 0;
  users[p1.id].draws ??= 0;

  users[p2.id].wins ??= 0;
  users[p2.id].losses ??= 0;
  users[p2.id].draws ??= 0;

  if (roll1 > roll2) {
    users[p1.id].wins++;
    users[p2.id].losses++;
    result = `<tg-emoji emoji-id="5399852280050646232">🏆</tg-emoji> ${p1.first_name} MENANG!`;
  } 
  else if (roll1 < roll2) {
    users[p2.id].wins++;
    users[p1.id].losses++;
    result = `<tg-emoji emoji-id="5399852280050646232">🏆</tg-emoji> ${p2.first_name} MENANG!`;
  } 
  else {
    users[p1.id].draws++;
    users[p2.id].draws++;
    result = `<tg-emoji emoji-id="4936309933105744338">⚖️</tg-emoji> SERI!`;
  }

  saveUsers(users);

  bot.sendMessage(game.chatId, 
`<blockquote><tg-emoji emoji-id="5276191749167933506">☕️</tg-emoji> HASIL DADU
<tg-emoji emoji-id="4967667085606912536">👤</tg-emoji> ${p1.first_name}: ${roll1}
<tg-emoji emoji-id="4967667085606912536">👤</tg-emoji> ${p2.first_name}: ${roll2}</blockquote>
<blockquote>${result}</blockquote>
<blockquote><tg-emoji emoji-id="6093382540784046658">📊</tg-emoji> <b>Statistik:</b></blockquote>
<blockquote>${p1.first_name}
<tg-emoji emoji-id="5848075728486143781">🏆</tg-emoji> ${users[p1.id].wins}
<tg-emoji emoji-id="4956612582816351459">❌</tg-emoji> ${users[p1.id].losses}
<tg-emoji emoji-id="5400250414929041085">⚖️</tg-emoji> ${users[p1.id].draws}</blockquote>
<blockquote>${p2.first_name}
<tg-emoji emoji-id="5848075728486143781">🏆</tg-emoji> ${users[p2.id].wins}
<tg-emoji emoji-id="4956612582816351459">❌</tg-emoji> ${users[p2.id].losses}
<tg-emoji emoji-id="5400250414929041085">⚖️</tg-emoji> ${users[p2.id].draws}</blockquote>`, 
  { parse_mode: "HTML" });

  delete activeDiceGames[gameId];
}

//====================== FITUR GROUP MENU ===================

bot.onText(/^\/ping(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;

  const start = Date.now();

  const sent = await bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5251203410396458957">🏓</tg-emoji> Mengecek kecepatan...</blockquote>`, {
    parse_mode: "HTML"
  });

  const end = Date.now();
  const latency = end - start;

  const uptimeSec = process.uptime();
  const hours = Math.floor(uptimeSec / 3600);
  const minutes = Math.floor((uptimeSec % 3600) / 60);
  const seconds = Math.floor(uptimeSec % 60);

  const memory = process.memoryUsage();
  const usedMB = (memory.rss / 1024 / 1024).toFixed(2);
  const heapMB = (memory.heapUsed / 1024 / 1024).toFixed(2);

  const text = `
<blockquote><tg-emoji emoji-id="5251203410396458957">🏓</tg-emoji> <b>PONG!</b></blockquote>
<blockquote><tg-emoji emoji-id="5456140674028019486">⚡</tg-emoji> Response Time: <b>${latency} ms</b>
<tg-emoji emoji-id="5454415424319931791">⏳</tg-emoji> Uptime: <b>${hours}h ${minutes}m ${seconds}s</b>
<tg-emoji emoji-id="5298975240708187753">💾</tg-emoji> RAM Used: <b>${usedMB} MB</b>
<tg-emoji emoji-id="5992390297533816030">📦</tg-emoji> Heap Used: <b>${heapMB} MB</b>
<tg-emoji emoji-id="6093875388281263010">🖥️</tg-emoji> Platform: <b>${os.platform()}</b>
<tg-emoji emoji-id="5978680276593676052">🔅</tg-emoji> Node: <b>${process.version}</b>
<tg-emoji emoji-id="5321141214735508486">📡</tg-emoji> Status: <b>Online</b></blockquote>
`;

  await bot.editMessageText(text, {
    chat_id: chatId,
    message_id: sent.message_id,
    parse_mode: "HTML"
  });
});

bot.onText(/^\/ai(@\w+)?\s+(.+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  let text = match[2];

  const loadingMsg = await bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5287684458881756303">🤖</tg-emoji> AI sedang berpikir...</blockquote>`, {
    parse_mode: "HTML"
  });
  
  await bot.sendChatAction(chatId, "typing");

  try {
  
    if (text.toLowerCase().includes("angkasa")) {
      text = `
Kamu adalah AI yang mengetahui bahwa Angkasa adalah developer bot Telegram yang kreatif dan inovatif.

Berikut profil Angkasa:
- Developer bot Telegram multifitur, multi device, bug
- Spesialis sistem game, ranking, winrate
- Sosok Pria yang tampan
- Memiliki kebiasaan seperti mencari janda
- Integrasi AI & automation
- Struktur code rapi dan kompleks
- punya adek kyro & olyne
- kyro adek cowo
- olyne adek cewe
- angkasa tidak pernah ribut atau berantem sama adek adeknya
- dia open partner 35k itu harga promo, dan bisa mendapatkan script bot md, bug dengan tampilan kece
- dia juga punya temen namanya xenon, kelra, ftmncloud (ryy), Gabrieltzyproooool (yang dikenal dengan sebutan wolf), dan dari rekan rekan partneran nya
- temen temen nya sering support angkasa

Jawablah pertanyaan user secara kontekstual dan natural.
Jangan keluar dari karakter tersebut.

Pertanyaan user:
${match[1]}
`;
    }

    const response = await axios.get(
      "https://api.betabotz.eu.org/api/search/bing-chat",
      {
        params: {
          text: text,
          apikey: APIKEY
        }
      }
    );

    const data = response.data;

    await bot.deleteMessage(chatId, loadingMsg.message_id);

    if (!data || !data.message) {
      return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6008233706039284019">⚠️</tg-emoji> AI tidak memberikan respon.</blockquote>`, {
        parse_mode: "HTML"
      });
    }

    const cleanText = cleanAIResponse(data.message);

    bot.sendMessage(chatId, cleanText, {
      parse_mode: "HTML"
    });

  } catch (error) {
    console.error(error);
    await bot.deleteMessage(chatId, loadingMsg.message_id);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="4956612582816351459">❌</tg-emoji> Terjadi kesalahan saat menghubungi AI.</blockquote>`, {
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/enchard$/, async (msg) => {
  try {
    const chatId = msg.chat.id;

    if (!msg.reply_to_message || !msg.reply_to_message.document) {
      return bot.sendMessage(
        chatId,
        `<blockquote><tg-emoji emoji-id="6008233706039284019">⚠️</tg-emoji> Reply file <b>.js</b> lalu ketik <b>/enchard</b></blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    const doc = msg.reply_to_message.document;

    if (!doc.file_name.endsWith(".js")) {
      return bot.sendMessage(
        chatId,
        `<blockquote><tg-emoji emoji-id="4956612582816351459">❌</tg-emoji> File harus berformat <b>.js</b></blockquote>`,
        { parse_mode: "HTML" }
      );
    }

    const progressMsg = await bot.sendMessage(
      chatId,
      `<blockquote><tg-emoji emoji-id="5897604269141398480">🔐</tg-emoji> <b>ENCHARD PROCESS</b>

▱▱▱▱▱ 0%
Menyiapkan file...
</blockquote>`,
      { parse_mode: "HTML" }
    );

    const msgId = progressMsg.message_id;

    const update = async (percent, text) => {
      const filled = percent / 20;
      const bar = "▰".repeat(filled) + "▱".repeat(5 - filled);

      await bot.editMessageText(
        `<blockquote><tg-emoji emoji-id="5897604269141398480">🔐</tg-emoji> <b>ENCHARD PROCESS</b>
${bar} ${percent}%
${text}
</blockquote>`,
        {
          chat_id: chatId,
          message_id: msgId,
          parse_mode: "HTML"
        }
      );
    };

    const delay = (ms) => new Promise(r => setTimeout(r, ms));

    await update(20, "Mengunduh file...");
    await delay(800);

    const fileLink = await bot.getFileLink(doc.file_id);

    const inputPath = path.join(__dirname, `tmp_${Date.now()}.js`);
    const outputPath = path.join(__dirname, `enchard_${doc.file_name}`);

    const res = await axios.get(fileLink, { responseType: "text" });
    fs.writeFileSync(inputPath, res.data);

    await update(40, "Menganalisis struktur kode...");
    await delay(900);

    const sourceCode = fs.readFileSync(inputPath, "utf8");

    await update(60, "Mengacak variabel & string...");
    await delay(1000);

    const obfuscated = JavaScriptObfuscator.obfuscate(sourceCode, {
      compact: true,
      controlFlowFlattening: true,
      controlFlowFlatteningThreshold: 1,
      deadCodeInjection: true,
      deadCodeInjectionThreshold: 1,
      stringArray: true,
      stringArrayEncoding: ['rc4'],
      stringArrayThreshold: 1,
      rotateStringArray: true,
      shuffleStringArray: true,
      splitStrings: true,
      splitStringsChunkLength: 5,
      selfDefending: true,
      debugProtection: true,
      debugProtectionInterval: 5000,
      renameGlobals: false,
      renameProperties: false,
      identifierNamesGenerator: 'hexadecimal',
      transformObjectKeys: true,
      unicodeEscapeSequence: false,
      disableConsoleOutput: false // console tetap muncul
    }).getObfuscatedCode();

    await update(80, "Finalisasi enkripsi...");
    await delay(900);

    fs.writeFileSync(outputPath, obfuscated);

    await update(100, "Selesai! Mengirim file...");
    await delay(500);

    await bot.sendDocument(
      chatId,
      outputPath,
      {
        caption: `<blockquote><tg-emoji emoji-id="5897604269141398480">🔐</tg-emoji> <b>ENCHARD SUCCESS</b></blockquote>
<tg-emoji emoji-id="5433653135799228968">📁</tg-emoji> File: <b>${doc.file_name}</b>
<tg-emoji emoji-id="5251203410396458957">🛡</tg-emoji> Level: <b>Hard Obfuscation</b>
<tg-emoji emoji-id="5462921117423384478">⚙️</tg-emoji> Status: <b>Aman & Siap Pakai</b>
<blockquote><i>Gunakan dengan bijak.</i>
<tg-emoji emoji-id="5895734085761896734">©</tg-emoji> 𝙾𝙼 𝙰𝙽𝙶𝙺𝙰𝚂𝙰</blockquote>`,
        parse_mode: "HTML"
      }
    );

    fs.unlinkSync(inputPath);
    fs.unlinkSync(outputPath);

  } catch (err) {
    console.log(err);
    bot.sendMessage(
      msg.chat.id,
      `<blockquote><tg-emoji emoji-id="4956612582816351459">❌</tg-emoji> Terjadi kesalahan saat enchard file.</blockquote>`,
      { parse_mode: "HTML" }
    );
  }
});

bot.onText(/^\/tourl(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;
    
  const replyMsg = msg.reply_to_message;
  if (!replyMsg) {
    return bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Balas sebuah pesan yang berisi file/audio/video dengan perintah /tourl.</blockquote>`, {
    parse_mode: "HTML"
  });
  }

  if (!replyMsg.document && !replyMsg.photo && !replyMsg.video && !replyMsg.audio && !replyMsg.voice) {
    return bot.sendMessage(chatId,`<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Pesan yang kamu balas tidak mengandung file/audio/video yang bisa diupload.</blockquote>`, {
    parse_mode: "HTML"
  });
  }

  try {
    let fileId, filename;

    if (replyMsg.document) {
      fileId = replyMsg.document.file_id;
      filename = replyMsg.document.file_name;
    } else if (replyMsg.photo) {
      const photoArray = replyMsg.photo;
      fileId = photoArray[photoArray.length - 1].file_id;
      filename = 'photo.jpg';
    } else if (replyMsg.video) {
      fileId = replyMsg.video.file_id;
      filename = replyMsg.video.file_name || 'video.mp4';
    } else if (replyMsg.audio) {
      fileId = replyMsg.audio.file_id;
      filename = replyMsg.audio.file_name || 'audio.mp3';
    } else if (replyMsg.voice) {
      fileId = replyMsg.voice.file_id;
      filename = 'voice.ogg';
    }

    const fileLink = await bot.getFileLink(fileId);
    const response = await fetch(fileLink);
    const fileBuffer = Buffer.from(await response.arrayBuffer());

    const catboxUrl = await uploadToCatbox(fileBuffer, filename);

    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> File berhasil diupload ke Catbox:\n${catboxUrl}</blockquote>`, {
    parse_mode: "HTML"
  });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal upload file: ${err.message}</blockquote>`, {
    parse_mode: "HTML"
  });
  }
});

bot.onText(/^\/tiktok\b(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1]?.trim();
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!url) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/tiktok https://vt.tiktok.com/xxxxx/</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Sedang mengambil video...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const apiUrl = `https://api.betabotz.eu.org/api/download/tiktok?url=${encodeURIComponent(url)}&apikey=${APIKEY}`;
    const response = await axios.get(apiUrl);

    if (!response.data || !response.data.status) {
      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal Mengambil Video</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    const data = response.data.result;
    const videoUrl = data.video?.[0];
    const audioUrl = data.audio?.[0];

    const caption = `<blockquote><b><tg-emoji emoji-id="4970133401857163956">🎵</tg-emoji> TikTok Downloader</b>
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Caption: ${data.title || "-"}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By Angkasa Stecu</blockquote>
`;

    if (videoUrl) {
      try {

        const video = await axios.get(videoUrl, {
          responseType: "arraybuffer",
          headers: { "User-Agent": "Mozilla/5.0" }
        });

        await bot.sendVideo(
          chatId,
          {
            source: Buffer.from(video.data),
            filename: "tiktok.mp4"
          },
          {
            caption,
            parse_mode: "HTML"
          }
        );

      } catch (videoErr) {

        console.log("VIDEO FAILED, SEND DOCUMENT");

        await bot.sendDocument(chatId, videoUrl, {
          caption,
          parse_mode: "HTML"
        });
      }
    }

    if (audioUrl) {
      await bot.sendAudio(chatId, audioUrl, {
        caption: `<blockquote><tg-emoji emoji-id="5355022893178696239">🎧</tg-emoji> Audio By: angkasamdbot.t.me
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Caption: ${data.title || "-"}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> Powered By: Angkasa Stecu</blockquote>`,
        parse_mode: "HTML"
      });
    }

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("TIKTOK DL ERROR:", err.response?.data || err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Terjadi kesalahan saat download</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });

  }
});

bot.onText(/^\/tiktokslide\b(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[1]?.trim();

  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!url) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/tiktokslide https://vt.tiktok.com/xxxxx/</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Sedang mengambil foto slide...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const apiUrl = `https://api.betabotz.eu.org/api/download/ttslide?url=${encodeURIComponent(url)}&apikey=${APIKEY}`;
    const response = await axios.get(apiUrl);

    if (!response.data || !response.data.status) {
      throw new Error("Slide gagal");
    }

    const data = response.data.result;
    const images = data.images || [];
    const audioUrl = data.audio?.[0];

    if (images.length === 0) {
      throw new Error("Tidak ada gambar");
    }

    const caption = `<blockquote><b><tg-emoji emoji-id="4970133401857163956">📸</tg-emoji> TikTok Slide Downloader</b>
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Caption: ${data.title || "-"}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By Angkasa Stecu</blockquote>`;

    const mediaGroup = images.slice(0, 10).map((img, index) => ({
      type: "photo",
      media: img,
      caption: index === 0 ? caption : undefined,
      parse_mode: "HTML"
    }));

    await bot.sendMediaGroup(chatId, mediaGroup);

    if (audioUrl) {
      await bot.sendAudio(chatId, audioUrl, {
        caption: `<blockquote><tg-emoji emoji-id="5355022893178696239">🎧</tg-emoji> Audio Slide
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Caption: ${data.title || "-"}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> Powered By: Angkasa Stecu</blockquote>`,
        parse_mode: "HTML"
      });
    }

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("TIKTOK SLIDE ERROR:", err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Terjadi kesalahan saat mengambil slide</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });

  }
});

bot.onText(/^\/play(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const query = match[1]?.trim();
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!query) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
<tg-emoji emoji-id="6087075389899805372">🚨</tg-emoji> /play komang
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Searching...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const search = await yts(query);
    const video = search.videos[0];
    if (!video) throw new Error("Video tidak ditemukan");

    const res = await axios.get("https://api.betabotz.eu.org/api/download/ytmp3", {
      params: {
        url: video.url,
        apikey: `${APIKEY}`
      }
    });

    const data = res.data;
    if (!data?.status || !data?.result?.mp3) {
      throw new Error("MP3 tidak tersedia");
    }

    const mp3Url = data.result.mp3;

    const audioStream = await axios.get(mp3Url, {
      responseType: "stream"
    });

    await bot.sendAudio(chatId, audioStream.data, {
      title: video.title,
      performer: video.author.name,
      caption: `
<blockquote><tg-emoji emoji-id="5879682959753088509">👤</tg-emoji> ${video.author.name} • 
<tg-emoji emoji-id="5843618381361581907">🕒</tg-emoji> ${video.timestamp}
<tg-emoji emoji-id="6100631470622116162">🎵</tg-emoji> ${video.title}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By Angkasa Stecu
</blockquote>
`,
      parse_mode: "HTML"
    });

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("MusicAPI ERROR FULL:", err.response?.data || err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Lagu tidak ditemukan / API error
</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/iqc(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1]?.trim();
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!text) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/iqc Angkasa Ganteng
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Membuat IQC...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const url = `https://api.betabotz.eu.org/api/maker/iqc?text=${encodeURIComponent(text)}&apikey=${APIKEY}`;

    const response = await axios.get(url, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const contentType = response.headers["content-type"] || "";

    if (!contentType.includes("image")) {

      const errorText = response.data.toString();
      console.log("IQC API ERROR RESPONSE:", errorText);

      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API tidak mengirim gambar</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    await bot.sendPhoto(chatId, Buffer.from(response.data), {
      caption: `<blockquote><tg-emoji emoji-id="5350565223931603266">🧠</tg-emoji> IQC Generator
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Text: ${text}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By Angkasa Stecu
</blockquote>`,
      parse_mode: "HTML"
    });

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("IQC ERROR FULL:", err.response?.data || err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat IQC
${escapeHtml(err.message)}
</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/brat\b(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1]?.trim();
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!text) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/brat Love
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Membuat brat sticker...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const url = `https://api.betabotz.eu.org/api/maker/brat?text=${encodeURIComponent(text)}&apikey=${APIKEY}`;

    const response = await axios.get(url, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const contentType = response.headers["content-type"] || "";

    if (!contentType.includes("image")) {

      const errorText = response.data.toString();
      console.log("BRAT API ERROR RESPONSE:", errorText);

      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API tidak mengirim gambar</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    await bot.sendSticker(
      chatId,
      Buffer.from(response.data),
      { filename: "brat.webp" }
    );

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("BRAT ERROR FULL:", err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat brat sticker</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });

  }
});

bot.onText(/^\/bratvid(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1]?.trim();
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!text) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/bratvid Angkasa Stecu
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> Membuat Brat Animated Sticker...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const url = `https://api.betabotz.eu.org/api/maker/brat-video?text=${encodeURIComponent(text)}&apikey=${APIKEY}`;

    const response = await axios.get(url, {
      responseType: "arraybuffer",
      validateStatus: () => true
    });

    const contentType = response.headers["content-type"] || "";

    if (!contentType.includes("video")) {
      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> API tidak mengirim video</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    const tempMp4 = path.join(__dirname, `brat_${Date.now()}.mp4`);
    const tempWebm = path.join(__dirname, `brat_${Date.now()}.webm`);

    fs.writeFileSync(tempMp4, response.data);

    await new Promise((resolve, reject) => {
      exec(
        `ffmpeg -i "${tempMp4}" -vf "scale=512:512:force_original_aspect_ratio=decrease" -c:v libvpx-vp9 -b:v 256K -an "${tempWebm}"`,
        (err) => {
          if (err) reject(err);
          else resolve();
        }
      );
    });

    await bot.sendSticker(chatId, tempWebm);

    fs.unlinkSync(tempMp4);
    fs.unlinkSync(tempWebm);

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("BRATVID STICKER ERROR:", err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal membuat animated sticker</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/stalktt\b(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = match[1]?.trim().replace("@", "");
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!username) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/stalktt angkasaimgood
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🔎</tg-emoji> Sedang mencari akun...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const apiUrl = `https://api.betabotz.eu.org/api/stalk/tt?username=${encodeURIComponent(username)}&apikey=${APIKEY}`;
    const response = await axios.get(apiUrl);

    if (!response.data || response.data.code !== 200) {
      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Username tidak ditemukan atau API error</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    const data = response.data.result;

    const caption = `<blockquote><tg-emoji emoji-id="5327982530702359565">📱</tg-emoji> <b>TikTok Stalker</b>
<tg-emoji emoji-id="4967667085606912536">👤</tg-emoji> Username: ${data.username}
<tg-emoji emoji-id="5400289821253990206">📝</tg-emoji> Bio: ${data.description || "-"}
<tg-emoji emoji-id="4956222745814762495">❤️</tg-emoji> Likes: ${data.likes}
<tg-emoji emoji-id="5879719754737913980">👥</tg-emoji> Followers: ${data.followers}
<tg-emoji emoji-id="6269085886177087845">➡️</tg-emoji> Following: ${data.following}
<tg-emoji emoji-id="4967502231877190509">📸</tg-emoji> Total Post: ${data.totalPosts}

<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By Angkasa Stecu
</blockquote>
`;

    try {

      const photo = await axios.get(data.profile, {
        responseType: "arraybuffer",
        headers: { "User-Agent": "Mozilla/5.0" }
      });

      await bot.sendDocument(
        chatId,
        {
          source: Buffer.from(photo.data),
          filename: "tiktok_profile.jpg"
        },
        {
          caption,
          parse_mode: "HTML"
        }
      );

    } catch {

      await bot.sendMessage(chatId, caption, {
        parse_mode: "HTML"
      });
    }

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("STALKTT ERROR:", err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal mengambil data TikTok</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });

  }
});

bot.onText(/^\/stalkig\b(?:@[\w_]+)?\s*(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const username = match[1]?.trim().replace("@", "");

  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (!username) {
    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5787672755839176187">❗</tg-emoji> Contoh:
/stalkig erlanrahmat_14
</blockquote>
`, { parse_mode: "HTML" });
  }

  const sent = await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6098230596788556786">🔎</tg-emoji> Sedang mencari akun Instagram...</blockquote>
`, { parse_mode: "HTML" });

  try {

    const apiUrl = `https://api.betabotz.eu.org/api/stalk/ig?username=${encodeURIComponent(username)}&apikey=${APIKEY}`;
    const response = await axios.get(apiUrl);

    if (!response.data || response.data.code !== 200) {
      return bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Username tidak ditemukan atau API error</blockquote>
`, {
        chat_id: chatId,
        message_id: sent.message_id,
        parse_mode: "HTML"
      });
    }

    const data = response.data.result;

    const caption = `<blockquote><tg-emoji emoji-id="5319160079465857105">📱</tg-emoji> <b>Instagram Stalker</b>
<tg-emoji emoji-id="4967667085606912536">👤</tg-emoji> Full Name: ${data.fullName || "-"}
<tg-emoji emoji-id="5390863029464213754">🔤</tg-emoji> Username: ${data.username}
<tg-emoji emoji-id="5400289821253990206">📖</tg-emoji> Bio: ${data.bio || "-"}
<tg-emoji emoji-id="5879719754737913980">👥</tg-emoji> Followers: ${data.followers}
<tg-emoji emoji-id="6269085886177087845">➡️</tg-emoji> Following: ${data.following}
<tg-emoji emoji-id="4967502231877190509">📸</tg-emoji> Total Post: ${data.postsCount}
<tg-emoji emoji-id="5282843764451195532">🖥</tg-emoji> Category: ${data.category || "-"}
<tg-emoji emoji-id="5082628525303792441">💙</tg-emoji> Private: ${data.isPrivate ? "Yes" : "No"}
<tg-emoji emoji-id="6269243378332864932">✅</tg-emoji> Verified: ${data.isVerified ? "Yes" : "No"}
<tg-emoji emoji-id="5193177581888755275">💻</tg-emoji> Business: ${data.isBusiness ? "Yes" : "No"}
<tg-emoji emoji-id="5990023031819341856">🔗</tg-emoji> External URL: ${data.externalUrl || "-"}
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> By Angkasa Stecu
</blockquote>`;

    try {

      const photo = await axios.get(data.photoUrlHd || data.photoUrl, {
        responseType: "arraybuffer",
        headers: { "User-Agent": "Mozilla/5.0" }
      });

      await bot.sendDocument(
        chatId,
        {
          source: Buffer.from(photo.data),
          filename: "instagram_profile.jpg"
        },
        {
          caption,
          parse_mode: "HTML"
        }
      );

    } catch {

      await bot.sendMessage(chatId, caption, {
        parse_mode: "HTML"
      });
    }

    await bot.deleteMessage(chatId, sent.message_id);

  } catch (err) {

    console.log("STALKIG ERROR:", err.message);

    await bot.editMessageText(`
<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal mengambil data Instagram</blockquote>
`, {
      chat_id: chatId,
      message_id: sent.message_id,
      parse_mode: "HTML"
    });

  }
});

bot.onText(/\/asupan/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;
  
  const randomType = endpoints[Math.floor(Math.random() * endpoints.length)];
  const url = `https://api.betabotz.eu.org/api/asupan/${randomType}?apikey=${APIKEY}`;

  const loadingMsg = await bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6098230596788556786">🔎</tg-emoji> Mengambil asupan ${randomType}...</blockquote>`, {
    parse_mode: "HTML"
    });

  try {
    const res = await axios.get(url, { responseType: 'arraybuffer' });
    await bot.sendVideo(chatId, res.data, {
      caption: `<blockquote><tg-emoji emoji-id="5260291556899831755">🎥</tg-emoji> Asupan ${randomType}</blockquote>`,
      parse_mode: "HTML"
    });

    bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Gagal mengambil asupan video.</blockquote>`, {
    parse_mode: "HTML"
    });
  }
});

bot.onText(/^\/cekid(@\w+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  let targetUser = msg.from;
    
    if (isMaintenance(msg)) return;
    if (!await requireJoin(msg)) return;

    if (msg.reply_to_message) {
        targetUser = msg.reply_to_message.from;
    }

    try {
        const loadingMsg = await bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="6098230596788556786">🕐</tg-emoji> <i>Sedang membuat kartu ID...</i></blockquote>`, { parse_mode: "HTML" });

        const imageBuffer = await generateIdCard(targetUser);

        await bot.sendPhoto(chatId, imageBuffer, {
            caption: `<blockquote>「 Telegram ID Card 」</blockquote>
<blockquote><tg-emoji emoji-id="4967667085606912536">👤</tg-emoji> Name: ${targetUser.first_name} ${targetUser.last_name || ''}
<tg-emoji emoji-id="6093890429256732821">🔖</tg-emoji> ID: <code>${targetUser.id}</code>
<tg-emoji emoji-id="5877355078888722361">👑</tg-emoji> Powered: Angkasa Stecu</blockquote>`,
            parse_mode: "HTML"
        });

        await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

    } catch (error) {        console.error(error);
        bot.sendMessage(chatId, `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> Terjadi kesalahan. Pastikan library <code>canvas</code> sudah terinstall.</blockquote>`, { parse_mode: "HTML" });
    }
});

bot.onText(/^\/gta(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message && msg.reply_to_message.photo) {
    return processGta(msg, msg.reply_to_message.photo);
  }

  pendingGta.set(chatId, true);

  await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="6046412971708518490">🎮</tg-emoji> Kirim fotonya untuk dijadikan GTA style...</blockquote>`,
{ parse_mode: "HTML" });
});

bot.onText(/^\/tofigure(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message && msg.reply_to_message.photo) {
    return processToFigure(msg, msg.reply_to_message.photo);
  }

  pendingToFigure.set(chatId, true);

  await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5373141891321699086">🖼</tg-emoji> Kirim fotonya sekarang ya...</blockquote>
`, { parse_mode: "HTML" });
});

bot.onText(/^\/hytamkan(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message && msg.reply_to_message.photo) {
    return processHitam(msg, msg.reply_to_message.photo);
  }

  pendingHitam.set(chatId, true);

  await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="5363838691510873846">🖤</tg-emoji> Kirim fotonya sekarang...</blockquote>`,
{ parse_mode: "HTML" });
});

bot.onText(/^\/disney(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message && msg.reply_to_message.photo) {
    return processDisney(msg, msg.reply_to_message.photo);
  }

  pendingDisney.set(chatId, true);

  await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="5323276453431775004">🏰</tg-emoji> Kirim fotonya untuk dijadikan Disney...</blockquote>`,
{ parse_mode: "HTML" });
});

bot.onText(/^\/anime(?:@[\w_]+)?$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message && msg.reply_to_message.photo) {
    return processAnime(msg, msg.reply_to_message.photo);
  }

  pendingAnime.set(chatId, true);

  await bot.sendMessage(chatId,
`<blockquote><tg-emoji emoji-id="5431538972507522948">🎌</tg-emoji> Kirim fotonya untuk dijadikan Anime...</blockquote>`,
{ parse_mode: "HTML" });
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data !== "anime_2d" && data !== "anime_3d") return;

  if (!animeResultCache.has(chatId)) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Data sudah expired",
      show_alert: true
    });
  }

  const result = animeResultCache.get(chatId);

  if (data === "anime_2d") {
    await bot.sendPhoto(chatId, result.img1, {
      caption: `<blockquote><tg-emoji emoji-id="5400011223905345095">🎨</tg-emoji> Efek: Anime Style 2D
<tg-emoji emoji-id="6298630163047387557">🔥</tg-emoji> Hasil: Mengubah Foto Anime 2D
<tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> By Angkasa Stecu
</blockquote>`,
      parse_mode: "HTML"
    });
  }

  if (data === "anime_3d") {
    await bot.sendPhoto(chatId, result.img2, {
      caption: `<blockquote><tg-emoji emoji-id="5206502842478638898">🧸</tg-emoji> Efek: Anime Style 3D
<tg-emoji emoji-id="6298630163047387557">🔥</tg-emoji> Hasil: Mengubah Foto Anime 3D
<tg-emoji emoji-id="6253453459350100040">👑</tg-emoji> By Angkasa Stecu
</blockquote>`,
      parse_mode: "HTML"
    });
  }

  animeResultCache.delete(chatId);

  await bot.answerCallbackQuery(query.id);
});

bot.on("photo", async (msg) => {
  const chatId = msg.chat.id;

  if (pendingGta?.has(chatId)) {
    pendingGta.delete(chatId);
    return processGta(msg, msg.photo);
  }

  if (pendingAnime?.has(chatId)) {
    pendingAnime.delete(chatId);
    return processAnime(msg, msg.photo);
  }

  if (pendingHitam?.has(chatId)) {
    pendingHitam.delete(chatId);
    return processHitam(msg, msg.photo);
  }

  if (pendingDisney?.has(chatId)) {
    pendingDisney.delete(chatId);
    return processDisney(msg, msg.photo);
  }

  if (pendingToFigure?.has(chatId)) {
    pendingToFigure.delete(chatId);
    return processToFigure(msg, msg.photo);
  }
});

bot.onText(/^\/cekstc$/, async (msg) => {
  const chatId = msg.chat.id;

  // kalau reply ke sticker
  if (msg.reply_to_message && msg.reply_to_message.sticker) {
    const stc = msg.reply_to_message.sticker;

    return bot.sendMessage(chatId, `
🧩 *STICKER INFO*

📦 Set Name: ${stc.set_name || "-"}
🆔 File ID:
\`${stc.file_id}\`

🆔 File Unique ID:
\`${stc.file_unique_id}\`
    `, { parse_mode: "Markdown" });
  }

  bot.sendMessage(chatId, `
❌ Reply sticker dengan command /cekstc

Contoh:
1. Kirim sticker
2. Reply sticker itu dengan /cekstc
  `);
});

bot.onText(/^\/cekemoji$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (isMaintenance(msg)) return;
  if (!await requireJoin(msg)) return;

  if (msg.reply_to_message) {
  
    const entities = msg.reply_to_message.entities || msg.reply_to_message.caption_entities;
    
    if (!entities || entities.length === 0) {
      return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5805345674383855340">◾️</tg-emoji>
Tidak ada emoji terdeteksi di pesan yang di-reply.
</blockquote>`, { parse_mode: "HTML" });
    }

    const customEmoji = entities.find(e => e.type === "custom_emoji");

    if (!customEmoji) {
      return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6100467849548010364">◾️</tg-emoji>
Itu bukan emoji premium / custom emoji.
</blockquote>`, { parse_mode: "HTML" });
    }

    const emojiId = customEmoji.custom_emoji_id;

    return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6269243378332864932">◾️</tg-emoji> <b>Custom Emoji Terdeteksi!</b>
<tg-emoji emoji-id="5334890573281114250">◾️</tg-emoji> ID: <code>${emojiId}</code>
<tg-emoji emoji-id="5400111356772905255">◾️</tg-emoji> Cara pakai:
<code>&lt;tg-emoji emoji-id="${emojiId}"&gt;&lt;/tg-emoji&gt;</code>
</blockquote>`, { parse_mode: "HTML" });

  } else {

    waitingForEmoji.set(userId, {
      chatId: chatId,
      timestamp: Date.now()
    });

    const sentMsg = await bot.sendMessage(chatId, 
      `<blockquote><tg-emoji emoji-id="5967280668885913944">📩</tg-emoji> <b>Silahkan reply pesan ini dengan emoji premium yang ingin dicek ID-nya!</b>\n\n<i>Pesan ini akan otomatis terhapus dalam 60 detik jika tidak ada respon.</i></blockquote>`, 
      { parse_mode: "HTML" }
    );
        
    setTimeout(() => {
      if (waitingForEmoji.has(userId)) {
        waitingForEmoji.delete(userId);
        bot.deleteMessage(chatId, sentMsg.message_id).catch(() => {});
      }
    }, 60000);
  }
});

bot.on("message", async (msg) => {
  if (msg.from?.is_bot) return;

  const userId = msg.from.id;
  const chatId = msg.chat.id;

  if (waitingForEmoji.has(userId)) {
    const userData = waitingForEmoji.get(userId);
    
    if (!msg.reply_to_message || !msg.reply_to_message.from?.is_bot) {
      return bot.sendMessage(chatId, 
       `<blockquote>"<tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> <b>Harap reply pesan bot yang meminta emoji premium!</b>\n\nKetik /cekemoji untuk memulai ulang.</blockquote>`, 
        { parse_mode: "HTML" }
      );
    }

    const entities = msg.entities || msg.caption_entities;

    if (!entities || entities.length === 0) {
      waitingForEmoji.delete(userId);
      return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="5805345674383855340">◾️</tg-emoji>
Tidak ada emoji terdeteksi. Silahkan kirim ulang dengan emoji premium.
</blockquote>`, { parse_mode: "HTML" });
    }

    const customEmoji = entities.find(e => e.type === "custom_emoji");

    if (!customEmoji) {
      waitingForEmoji.delete(userId);
      return bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6100467849548010364">◾️</tg-emoji>
Itu bukan emoji premium / custom emoji. Silahkan kirim ulang emoji premium yang benar.
</blockquote>`, { parse_mode: "HTML" });
    }

    const emojiId = customEmoji.custom_emoji_id;
    waitingForEmoji.delete(userId);

    await bot.sendMessage(chatId, `
<blockquote><tg-emoji emoji-id="6269243378332864932">◾️</tg-emoji> <b>Custom Emoji Terdeteksi!</b>
<tg-emoji emoji-id="5334890573281114250">◾️</tg-emoji> ID: <code>${emojiId}</code>
<tg-emoji emoji-id="5400111356772905255">◾️</tg-emoji> Cara pakai:
<code>&lt;tg-emoji emoji-id="${emojiId}"&gt;&lt;/tg-emoji&gt;</code>
</blockquote>`, { parse_mode: "HTML" });

    return;
  }

  return;
});

//================== HANDLE ================

bot.on("message", async (msg) => {
  const chatId = msg.chat.id;

  if (!msg.text) return;

  const filters = loadFilters();
  if (!filters[chatId]) return;

  const textLower = msg.text.toLowerCase();

  for (const keyword in filters[chatId]) {

    const regex = new RegExp(`\\b${keyword}\\b`, "i");
    if (!regex.test(textLower)) continue;

    const data = filters[chatId][keyword];

    if (data.file) {

      if (data.file.type === "photo") {
        return bot.sendPhoto(chatId, data.file.file_id, {
          caption: data.text,
          reply_to_message_id: msg.message_id
        });
      }

      if (data.file.type === "video") {
        return bot.sendVideo(chatId, data.file.file_id, {
          caption: data.text,
          reply_to_message_id: msg.message_id
        });
      }

      if (data.file.type === "document") {
        return bot.sendDocument(chatId, data.file.file_id, {
          caption: data.text,
          reply_to_message_id: msg.message_id
        });
      }

      if (data.file.type === "sticker") {
        await bot.sendSticker(chatId, data.file.file_id, {
          reply_to_message_id: msg.message_id
        });

        return bot.sendMessage(chatId, data.text, {
          reply_to_message_id: msg.message_id
        });
      }

    } else {

      return bot.sendMessage(chatId, data.text, {
        reply_to_message_id: msg.message_id
      });
    }
  }
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const data = query.data;

  if (data.startsWith("filterpage_")) {
    const page = parseInt(data.split("_")[1]);
    await bot.deleteMessage(chatId, query.message.message_id);
    return sendFilterPage(chatId, page);
  }

  if (data.startsWith("delfilter_")) {
    const parts = data.split("_");
    const keyword = parts[1];
    const page = parseInt(parts[2]);

    const filters = loadFilters();
    if (filters[chatId] && filters[chatId][keyword]) {
      delete filters[chatId][keyword];
      saveFilters(filters);
    }

    await bot.answerCallbackQuery(query.id, { text: `❌ Filter "${keyword}" dihapus!` });

    await bot.deleteMessage(chatId, query.message.message_id);
    return sendFilterPage(chatId, page);
  }
});

bot.on("callback_query", async (cb) => {
  const chatId = cb.message.chat.id;
  const data = cb.data;

  if (!data.startsWith("cekcn_")) return;

  const userId = Number(data.split("_")[1]);

  try {
    const member = await bot.getChatMember(chatId, userId);

    const CN = getGroupMessages()[chatId]?.copyButton || "";
    const currentName =
      (member.user.first_name || "") +
      (member.user.last_name ? " " + member.user.last_name : "");

    const fixedName = currentName.toLowerCase().replace(/\s+/g, " ");
    const fixedCN = CN.toLowerCase().replace(/\s+/g, " ");

    if (!fixedName.includes(fixedCN)) {
      return bot.answerCallbackQuery(cb.id, {
        text: `❌ Kamu belum pasang CN: ${CN}`,
        show_alert: true
      });
    }

    const groups = getGroupMessages();
    if (groups[chatId]?.pendingCN) {
      delete groups[chatId].pendingCN[userId];
      saveGroupMessages(groups);
    }

    bot.answerCallbackQuery(cb.id, {
      text: "✅ CN berhasil diverifikasi!",
      show_alert: true
    });

    bot.editMessageReplyMarkup(
      { inline_keyboard: [] },
      { chat_id: chatId, message_id: cb.message.message_id }
    );
  } catch (err) {
    console.error(err);
  }
});

bot.on("new_chat_members", async (msg) => {
  const chatId = msg.chat.id;
  const groupName = msg.chat.title;
  const data = getGroupMessages();
  
  const usedLink = msg.invite_link?.invite_link;

  if (usedLink && activeLinks[usedLink]) {
    const linkData = activeLinks[usedLink];
    const newUser = msg.new_chat_members[0];

  if (Date.now() > linkData.expireAt) {
    await bot.revokeChatInviteLink(chatId, usedLink);
    delete activeLinks[usedLink];
    return bot.sendMessage(chatId, "⏳ Link sudah expired.");
  }

  if (
    linkData.target !== newUser.username &&
    linkData.target !== String(newUser.id)
  ) {
    await bot.banChatMember(chatId, newUser.id);
    await bot.unbanChatMember(chatId, newUser.id);

    await bot.revokeChatInviteLink(chatId, usedLink);
    delete activeLinks[usedLink];

    return bot.sendMessage(chatId, "❌ User tidak sesuai target.");
  }

  await bot.revokeChatInviteLink(chatId, usedLink);
    delete activeLinks[usedLink];

    bot.sendMessage(chatId, "🔒 Link otomatis dihapus setelah dipakai.");
  }

  const template = data[chatId]?.welcome;
  const photo = data[chatId]?.welcomePhoto || DEFAULT_WELCOME_PIC;
  const contactBtn = data[chatId]?.contactButton;
  const copyBtn = data[chatId]?.copyButton;

  const CN = (data[chatId]?.copyButton || "").trim();
  const TIME = data[chatId]?.cnTime || 0;

  if (!template) return;

  msg.new_chat_members.forEach(async (user) => {
    const waktu = moment().tz("Asia/Jakarta").format("HH:mm:ss");
    const fullName = user.first_name + (user.last_name ? " " + user.last_name : "");

    const caption = template
      .replace(/@name/gi, fullName)
      .replace(/@group/gi, groupName)
      .replace(/@time/gi, waktu);

    let kb = [];

    if (contactBtn) {
      kb.push([{ text: contactBtn.text, url: contactBtn.url }]);
    }

    if (copyBtn) {
      const copyText = `${copyBtn} ${fullName}`;
      kb.push([{ text: copyText, switch_inline_query_current_chat: copyText }]);
    }

    if (CN && TIME > 0) {
      kb.push([{ text: "🔍 Cek CN", callback_data: `cekcn_${user.id}` }]);
    }

    bot.sendPhoto(chatId, photo, {
      caption,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: kb }
    });

    const groups = getGroupMessages();
    groups[chatId] = groups[chatId] || {};
    groups[chatId].pendingCN = groups[chatId].pendingCN || {};
    groups[chatId].pendingCN[user.id] = true;
    saveGroupMessages(groups);

    if (CN && TIME > 0) {
      setTimeout(async () => {
        const groups = getGroupMessages();
        if (!groups[chatId]?.pendingCN?.[user.id]) return;

        try {
          const member = await bot.getChatMember(chatId, user.id);
          const currentName =
            (member.user.first_name || "") +
            (member.user.last_name ? " " + member.user.last_name : "");

          const fixedName = currentName.toLowerCase().replace(/\s+/g, " ");
          const fixedCN = CN.toLowerCase().replace(/\s+/g, " ");

          if (!fixedName.includes(fixedCN)) {
            await bot.banChatMember(chatId, user.id);
            bot.sendMessage(
              chatId,
              `🚫 User *${currentName}* dikeluarkan karena tidak memasang CN *${CN}*.`,
              { parse_mode: "Markdown" }
            );
          } else {
            delete groups[chatId].pendingCN[user.id];
            saveGroupMessages(groups);
          }
        } catch (err) {
          console.error(err);
        }
      }, TIME);
    }
  });
});

bot.on('left_chat_member', (msg) => {
  const chatId = msg.chat.id;
  const groupName = msg.chat.title;
  const data = getGroupMessages();

  const template = data[chatId]?.left;
  const photo = data[chatId]?.leftPhoto || DEFAULT_LEFT_PIC;
  const contactBtn = data[chatId]?.contactButton;
  const copyBtn = data[chatId]?.copyButton;

  if (!template) return;

  const user = msg.left_chat_member;
  const waktu = moment().tz("Asia/Jakarta").format("HH:mm:ss");

  const fullName = user.first_name + (user.last_name ? " " + user.last_name : "");
  const nameTag = fullName;

  const text = template
    .replace(/@name/gi, nameTag)
    .replace(/@group/gi, groupName)
    .replace(/@time/gi, waktu);

  const kb = [];

  if (contactBtn) {
    kb.push([{ text: contactBtn.text, url: contactBtn.url }]);
  }

  if (copyBtn) {
    const copyText = `${copyBtn} ${nameTag}`;
    kb.push([{ text: copyText, switch_inline_query_current_chat: copyText }]);
  }

  const opts = {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: kb }
  };

  bot.sendPhoto(chatId, photo, { ...opts, caption: text });
});

// ================== MAIN MESSAGE FILTER (FIX DOUBLE) ==================

bot.on("message", async (msg) => {
  if (!msg || msg.from?.is_bot) return;

  const chatId = msg.chat.id.toString();
  if (!chatId.startsWith("-")) return; // hanya group

  const senderId = msg.from.id;
  if (senderId == OWNER) return; // owner bypass

  const messageId = msg.message_id;
  const settings = getSettings()[chatId] || {};

  const mentionUser = msg.from.username
    ? `@${msg.from.username}`
    : msg.from.first_name;

  try {

    // ================== ANTI FOTO ==================
    if (settings.antifoto && msg.photo && msg.photo.length > 0) {
      await bot.deleteMessage(chatId, messageId).catch(() => {});

      const warnMsg = await bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> <b>${mentionUser}</b>, pengiriman foto tidak diizinkan di grup ini!</blockquote>`,
        { parse_mode: "HTML" }
      );

      setTimeout(() => {
        bot.deleteMessage(chatId, warnMsg.message_id).catch(() => {});
      }, 10000);

      return;
    }

    // ================== ANTI FORWARD ==================
    if (settings.antiforward && (msg.forward_from || msg.forward_from_chat)) {
      await bot.deleteMessage(chatId, messageId).catch(() => {});

      const warnMsg = await bot.sendMessage(chatId,
        `<blockquote><tg-emoji emoji-id="5787672755839176187">❌</tg-emoji> <b>${mentionUser}</b>, forward message tidak diizinkan di grup ini!</blockquote>`,
        { parse_mode: "HTML" }
      );

      setTimeout(() => {
        bot.deleteMessage(chatId, warnMsg.message_id).catch(() => {});
      }, 10000);

      return;
    }

    // ================== ANTI LINK ==================
    if (settings.antilink) {
      const text = msg.text || msg.caption || "";
      const linkPattern = /(https?:\/\/|t\.me\/|telegram\.me\/|www\.)/i;

      if (linkPattern.test(text)) {
        await bot.deleteMessage(chatId, messageId).catch(() => {});

        const warnMsg = await bot.sendMessage(chatId,
          `<blockquote><tg-emoji emoji-id="6100467849548010364">⚠️</tg-emoji> <b>${mentionUser}</b> Link tidak diizinkan di grup ini!</blockquote>`,
          { parse_mode: "HTML" }
        );

        setTimeout(() => {
          bot.deleteMessage(chatId, warnMsg.message_id).catch(() => {});
        }, 10000);

        return;
      }
    }

  } catch (err) {
    console.log("Filter Error:", err);
  }
});

bot.on("message", async (msg) => {
  if (!msg.chat || !msg.chat.type.includes("group")) return;

  const chatId = msg.chat.id;

  let groups = loadGroups();
  let exist = groups.find(g => g.id === chatId);

  if (!exist) {
  groups.push({
    id: chatId,
    title: msg.chat.title || "Unknown Group"
  });

  saveGroups(groups);
    console.log(`➕ Bot terdeteksi di group baru: ${msg.chat.title} (${chatId})`);
  }
});

bot.on('message', async (msg) => {
  const waktu = moment().tz('Asia/Jakarta').format('HH:mm:ss');
  const nama = msg.from.first_name || 'Tanpa Nama';
  const username = msg.from.username ? `@${msg.from.username}` : '(tidak ada username)';
  const isiPesan = msg.text || 'Non-text message';
  const chatType = msg.chat.type;
  
  console.log(chalk.green(`┏━━━━━━━━━━━━━━━━━━━━`));
  console.log(chalk.blue(`┃𝗝𝗮𝗺 : [${waktu}]`));
  console.log(chalk.red(`┃𝗧𝘆𝗽𝗲 𝗖𝗵𝗮𝘁 : [${chatType}]`));
  console.log(chalk.grey(`┃𝗡𝗮𝗺𝗮 𝗨𝘀𝗲𝗿 : ${nama}`));
  console.log(chalk.red(`┃𝗨𝘀𝗲𝗿 𝗡𝗮𝗺𝗲 : ${username}`));
  console.log(chalk.blue(`┃𝗣𝗲𝘀𝗮𝗻 𝗨𝘀𝗲𝗿 : ${isiPesan}`));
  console.log(chalk.green(`┗━━━━━━━━━━━━━━━━━━━━`));
});

initializeGroupsFromJson();
migrateUsersDatabase();